'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthProvider';
import { 
  ChevronLeft, 
  Save, 
  Eye, 
  Loader2,
  AlertTriangle,
  Type,
  AlignLeft,
  Settings2,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function ChapterEditor() {
  const { id: storyId, chapterId } = useParams();
  const router = useRouter();
  const { profile } = useAuth();
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [chapterNumber, setChapterNumber] = useState(1);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(chapterId !== 'new');
  const [wordCount, setWordCount] = useState(0);

  useEffect(() => {
    async function fetchChapter() {
      if (chapterId === 'new') {
        // Find next chapter number
        const { data } = await (supabase
          .from('chapters')
          .select('chapter_number')
          .eq('story_id', storyId)
          .order('chapter_number', { ascending: false })
          .limit(1) as any);
        
        if (data && data[0]) setChapterNumber((data[0] as any).chapter_number + 1);
        return;
      }

      const { data, error } = await (supabase
        .from('chapters')
        .select('*')
        .eq('id', chapterId)
        .single() as any);

      if (data) {
        const chapterData = data as any;
        setTitle(chapterData.title);
        setContent(chapterData.content);
        setChapterNumber(chapterData.chapter_number);
      }
      setIsLoading(false);
    }

    if (chapterId) fetchChapter();
  }, [chapterId, storyId]);

  useEffect(() => {
    const words = content.trim() ? content.trim().split(/\s+/).length : 0;
    setWordCount(words);
  }, [content]);

  const handleSave = async (isDraft = true) => {
    if (!profile) return;
    setIsSaving(true);

    const chapterData = {
      story_id: storyId,
      title: title || `Chapter ${chapterNumber}`,
      content,
      chapter_number: chapterNumber,
      is_locked: chapterNumber > 3,
      coin_price: 20 // Default price
    };

    try {
      if (chapterId === 'new') {
        const { data, error } = await (supabase.from('chapters') as any)
          .insert(chapterData as any)
          .select()
          .single();
        if (error) throw error;
        router.push(`/story/${storyId}/chapter/edit/${data.id}`);
      } else {
        const { error } = await (supabase.from('chapters') as any)
          .update(chapterData as any)
          .eq('id', chapterId);
        if (error) throw error;
        alert('Chapter saved successfully!');
      }
    } catch (err) {
      console.error(err);
      alert('Save failed');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf]">
      
      {/* Immersive Background */}
      <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-20" />

      {/* Control Bar */}
      <header className="relative z-10 p-6 flex justify-between items-center glass-nav border-b border-white/5 sticky top-0">
        <button onClick={() => router.push(`/story/edit/${storyId}`)} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center">
          <ChevronLeft size={24} />
        </button>
        
        <div className="flex flex-col items-center">
           <span className="text-[9px] font-black uppercase tracking-[0.2em] text-[#f2994a]">Writing Studio</span>
           <span className="text-[10px] opacity-40 font-serif italic truncate max-w-[150px]">
             {title || 'Untitled Chapter'}
           </span>
        </div>

        <div className="flex gap-2">
           <button 
             onClick={() => handleSave()}
             disabled={isSaving}
             className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2"
           >
             {isSaving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />} Save
           </button>
        </div>
      </header>

      <main className="relative z-10 max-w-3xl mx-auto p-6 md:p-12 space-y-10">
        
        {/* Editor Inputs */}
        <section className="space-y-12">
            
           {/* Meta Row */}
           <div className="flex items-center gap-6 border-b border-white/5 pb-8">
              <div className="space-y-1">
                 <label className="text-[9px] font-black uppercase tracking-widest text-white/30">Number</label>
                 <input 
                   type="number"
                   value={chapterNumber}
                   onChange={(e) => setChapterNumber(parseInt(e.target.value))}
                   className="w-16 bg-white/5 border border-white/10 rounded-lg p-2 text-center font-black text-[#f2994a] outline-none focus:border-[#f2994a]/50"
                 />
              </div>
              <div className="flex-1 space-y-1">
                 <label className="text-[9px] font-black uppercase tracking-widest text-white/30">Chapter Title (የምዕራፍ ርዕስ)</label>
                 <input 
                   value={title}
                   onChange={(e) => setTitle(e.target.value)}
                   placeholder="E.g. A New Beginning..."
                   className="w-full bg-transparent p-0 text-2xl font-serif font-bold italic outline-none placeholder:text-white/10"
                 />
              </div>
           </div>

           {/* Content Editor Area */}
           <div className="min-h-[60vh] space-y-4">
              <div className="flex items-center justify-between text-[9px] font-black uppercase tracking-[0.2em] text-white/20">
                 <div className="flex gap-4">
                    <span className="flex items-center gap-1"><AlignLeft size={10} /> {wordCount} Words</span>
                    <span className="flex items-center gap-1"><Type size={10} /> Amharic Supported</span>
                 </div>
                 <button className="hover:text-[#f2994a] transition-colors">
                    <Settings2 size={12} />
                 </button>
              </div>

              <textarea 
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="ታሪክዎን እዚህ መጻፍ ይጀምሩ... (Start writing your story here...)"
                className="w-full min-h-[60vh] bg-transparent font-serif text-lg leading-[2] tracking-wide outline-none resize-none placeholder:text-white/5"
              />
           </div>
        </section>

        {/* Professional Note */}
        <section className="bg-[#2a1d15]/30 border border-[#f2994a]/10 rounded-2xl p-6 flex gap-4">
           <AlertTriangle className="text-[#f2994a] flex-shrink-0" size={20} />
           <p className="text-[10px] opacity-60 leading-relaxed font-serif italic">
             "የምዕራፍ ዋጋ እና ቁልፍ አመዳደብ የጥራት ደረጃን ለመጠበቅ በፕላትፎርሙ አስተዳዳሪዎች የሚተዳደር ነው።"
             <br /><br />
             Note: Chapter pricing and locking mechanisms are system-managed to ensure platform sustainability and quality standards.
           </p>
        </section>

        {/* Global Action */}
        <div className="pt-8">
           <button 
             onClick={() => handleSave(false)}
             className="w-full py-5 bg-[#f2994a] text-black font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-[#f2994a]/20 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
           >
             Finish & Sync Chapter
           </button>
        </div>

      </main>

      {/* Tool Sidebar (Desktop) */}
      <aside className="hidden lg:flex fixed right-10 top-32 flex-col gap-4">
         {[1, 2, 3].map(i => (
           <div key={i} className="w-12 h-12 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center text-white/20 hover:text-[#f2994a] hover:border-[#f2994a]/20 transition-all cursor-pointer">
             <FileText size={20} />
           </div>
         ))}
      </aside>
    </div>
  );
}
