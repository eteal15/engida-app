'use client';

import { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthProvider';
import { 
  ChevronLeft, 
  Camera, 
  Save, 
  Send, 
  Trash2, 
  Plus,
  Loader2,
  FileText
} from 'lucide-react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';

const GENRES = [
  'Romance', 'Dark Romance', 'Thriller', 'Mystery', 
  'Comedy', 'Spiritual', 'Horror', 'Adventure', 
  'Historical', 'Drama', 'Crime', 'Fantasy'
];

export default function StoryEditor() {
  const { id } = useParams();
  const router = useRouter();
  const { profile } = useAuth();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [genre, setGenre] = useState('');
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(id !== 'create');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    async function fetchStory() {
      if (id === 'create') return;
      
      const { data, error } = await (supabase
        .from('stories')
        .select('*')
        .eq('id', id)
        .single() as any);

      if (data) {
        const storyData = data as any;
        setTitle(storyData.title);
        setDescription(storyData.description || '');
        setGenre(storyData.genre || '');
        setCoverUrl(storyData.cover_url);
      }
      setIsLoading(false);
    }

    if (id) fetchStory();
  }, [id]);

  const handleUploadCover = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;

    setIsUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${profile.id}-${Date.now()}.${fileExt}`;
      const filePath = `covers/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('payouts') // Assuming/using general bucket
        .upload(filePath, file);

      if (uploadError) throw uploadError;
      setCoverUrl(filePath);
    } catch (err) {
      console.error(err);
      alert('Upload failed');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSave = async (status: 'draft' | 'pending' = 'draft') => {
    if (!profile) return;
    setIsSaving(true);

    const storyData = {
      title,
      description,
      genre,
      cover_url: coverUrl,
      author_id: profile.id,
      status: status
    };

    try {
      if (id === 'create') {
        const { data, error } = await (supabase.from('stories') as any)
          .insert(storyData as any)
          .select()
          .single();

        if (error) throw error;
        router.push(`/story/edit/${data.id}`);
      } else {
        const { error } = await (supabase.from('stories') as any)
          .update(storyData as any)
          .eq('id', id);

        if (error) throw error;
        alert(`Story saved as ${status}!`);
      }
    } catch (err) {
      console.error(err);
      alert('Save failed');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-32">
      <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-30" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center glass-nav border-b border-white/5 sticky top-0">
        <button onClick={() => router.push('/writer-dashboard')} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center">
          <ChevronLeft size={24} />
        </button>
        <span className="text-xs font-black uppercase tracking-[0.2em] opacity-40">Story Studio</span>
        <div className="flex gap-2">
           <button 
             disabled={isSaving}
             onClick={() => handleSave('draft')}
             className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10"
           >
             {isSaving ? <Loader2 size={14} className="animate-spin" /> : 'Save Draft'}
           </button>
        </div>
      </header>

      <main className="relative z-10 p-6 space-y-8 max-w-2xl mx-auto">
        
        {/* Cover Image Upload */}
        <section className="space-y-4">
           <div className="relative aspect-[3/4] w-48 mx-auto rounded-3xl overflow-hidden border border-white/10 bg-white/5 group">
              {coverUrl ? (
                <Image 
                  src={coverUrl} 
                  alt="Cover" 
                  fill 
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center gap-2 opacity-20">
                   <Camera size={32} />
                   <span className="text-[10px] font-black uppercase">Cover Photo</span>
                </div>
              )}
              
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer"
              >
                 {isUploading ? <Loader2 size={24} className="animate-spin text-[#f2994a]" /> : <Plus size={32} />}
              </div>
              <input 
                ref={fileInputRef}
                type="file" 
                hidden 
                accept="image/*"
                onChange={handleUploadCover}
              />
           </div>
        </section>

        {/* Form Fields */}
        <section className="space-y-6">
           <div className="space-y-2">
             <label className="text-[10px] font-black uppercase tracking-widest text-white/30">Story Title (የርዕስ ስም)</label>
             <input 
               value={title}
               onChange={(e) => setTitle(e.target.value)}
               placeholder="Enter a captivating title..."
               className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-lg font-serif focus:border-[#f2994a]/50 outline-none transition-all placeholder:text-white/10"
             />
           </div>

           <div className="space-y-2">
             <label className="text-[10px] font-black uppercase tracking-widest text-white/30">Select Genre (ዘውግ)</label>
             <select 
               value={genre}
               onChange={(e) => setGenre(e.target.value)}
               className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-sm focus:border-[#f2994a]/50 outline-none appearance-none transition-all"
             >
               <option value="" disabled>Choose a genre...</option>
               {GENRES.map(g => (
                 <option key={g} value={g} className="bg-[#0d0b0a]">{g}</option>
               ))}
             </select>
           </div>

           <div className="space-y-2">
             <label className="text-[10px] font-black uppercase tracking-widest text-white/30">Synopsis (አጭር መግለጫ)</label>
             <textarea 
               value={description}
               onChange={(e) => setDescription(e.target.value)}
               rows={5}
               placeholder="What is this story about? Catch the reader's attention..."
               className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-sm font-serif leading-relaxed focus:border-[#f2994a]/50 outline-none transition-all placeholder:text-white/10"
             />
           </div>
        </section>

        {/* Chapters Section (If not creating) */}
        {id !== 'create' && (
          <section className="pt-8 border-t border-white/5 space-y-6">
             <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase tracking-widest text-[#f2994a]">Chapters</h3>
                <Link 
                  href={`/story/${id}/chapter/edit/new`} 
                  className="flex items-center gap-2 text-[10px] font-black uppercase text-white/60 hover:text-[#f2994a] transition-colors"
                >
                  <Plus size={14} /> Add Chapter
                </Link>
             </div>
             
             {/* Chapter List */}
             <div className="bg-white/5 rounded-2xl border border-white/5 overflow-hidden">
                <div className="p-10 text-center opacity-20 italic text-sm font-serif">
                   Manage chapters to build your serial...
                </div>
             </div>
          </section>
        )}

        {/* Action Button */}
        <section className="pt-10">
           <button 
             onClick={() => handleSave('pending')}
             className="w-full py-5 bg-[#f2994a] text-black font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-[#f2994a]/20 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
           >
             <Send size={16} /> Submit for Platform Review
           </button>
           <p className="text-[9px] text-center mt-4 opacity-40 uppercase tracking-widest leading-relaxed">
             Once submitted, administrators will review your story's quality before publishing.
           </p>
        </section>

      </main>
    </div>
  );
}
