import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { AuthProvider } from '@/context/AuthProvider';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'ENGIDA - Ethiopian Storytelling',
  description: 'Immersive Amharic serialized fiction platform.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="am" suppressHydrationWarning>
      <body className={inter.className}>
        <AuthProvider>
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}
