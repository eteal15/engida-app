import { redirect } from 'next/navigation';

// Root page: redirect to login (AuthProvider handles redirect to /home if already logged in)
export default function Home() {
  redirect('/login');
}
