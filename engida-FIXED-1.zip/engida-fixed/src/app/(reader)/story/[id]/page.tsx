'use client';

import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Database } from '@/types/database.types';
import { useAuth } from '@/context/AuthProvider';
import ChapterList from '@/components/reader/ChapterList';
import { ChevronLeft, Share2, Bookmark, Heart, MessageSquare, Play } from 'lucide-react';
import Image from 'next/image';
import { motion } from 'framer-motion';

type Story = Database['public']['Tables']['stories']['Row'] & {
  profiles: { full_name: string | null; avatar_url: string | null } | null;
};

export default function StoryDetails() {
  const { id } = useParams();
  const router = useRouter();
  const { profile } = useAuth();
  const [story, setStory] = useState<Story | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchStory() {
      const { data, error } = await (supabase
        .from('stories')
        .select('*, profiles(full_name, avatar_url)')
        .eq('id', id)
        .single() as any);

      if (error) {
        console.error('Error fetching story:', error);
        return;
      }

      setStory(data as any);
      setIsLoading(false);
    }

    if (id) fetchStory();
  }, [id]);

  if (isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;
  if (!story) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center">ታሪኩ አልተገኘም</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-24">
      {/* Immersive Background */}
      <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-40" />

      {/* Header/Cover Section */}
      <div className="relative h-[45vh] w-full overflow-hidden">
        {story.cover_url ? (
          <Image
            src={story.cover_url}
            alt={story.title}
            fill
            className="object-cover blur-[2px] scale-105 opacity-60"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-b from-gray-800 to-[#0d0b0a]" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0d0b0a] via-transparent to-black/40" />
        
        {/* Top Controls */}
        <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-20">
          <button 
            onClick={() => router.back()}
            className="w-10 h-10 rounded-full glass-nav flex items-center justify-center border border-white/10 "
          >
            <ChevronLeft size={24} />
          </button>
          <div className="flex gap-3">
             <button className="w-10 h-10 rounded-full glass-nav flex items-center justify-center border border-white/10">
               <Share2 size={18} />
             </button>
             <button className="w-10 h-10 rounded-full glass-nav flex items-center justify-center border border-white/10">
               <Bookmark size={18} />
             </button>
          </div>
        </div>

        {/* Content Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-6 space-y-4">
           <div className="flex gap-2">
             <span className="px-2 py-0.5 bg-[#f2994a] text-black text-[9px] font-black uppercase rounded">{story.genre || 'Story'}</span>
             <span className="px-2 py-0.5 bg-white/10 backdrop-blur-md text-white text-[9px] font-black uppercase rounded">Serialized</span>
           </div>
           <h1 className="text-3xl md:text-5xl font-serif font-bold tracking-tight leading-tight">{story.title}</h1>
           <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full bg-gray-700 relative overflow-hidden">
                {story.profiles?.avatar_url && (
                  <Image src={story.profiles.avatar_url} alt="Author" fill className="object-cover" />
                )}
              </div>
              <span className="text-xs font-bold opacity-60 uppercase tracking-widest">{story.profiles?.full_name || 'Author'}</span>
           </div>
        </div>
      </div>

      <main className="relative z-10 px-6 mt-8 space-y-10">
        
        {/* Story Stats Bar */}
        <div className="flex justify-around items-center py-6 border-y border-white/5">
           <div className="text-center">
             <p className="text-lg font-bold">{(story.views_count / 1000).toFixed(1)}k</p>
             <p className="text-[9px] text-white/30 uppercase tracking-widest">Views</p>
           </div>
           <div className="w-px h-8 bg-white/5" />
           <div className="text-center">
             <p className="text-lg font-bold">{(story.likes_count / 1000).toFixed(1)}k</p>
             <p className="text-[9px] text-white/30 uppercase tracking-widest">Likes</p>
           </div>
           <div className="w-px h-8 bg-white/5" />
           <div className="text-center">
             <p className="text-lg font-bold">12</p>
             <p className="text-[9px] text-white/30 uppercase tracking-widest">Chapters</p>
           </div>
        </div>

        {/* Description Section */}
        <div className="space-y-4">
           <h2 className="text-xs font-black uppercase tracking-[0.3em] text-[#f2994a]">መግለጫ (Description)</h2>
           <p className="text-base opacity-70 font-serif leading-relaxed line-clamp-4">
             {story.description || 'ምንም መግለጫ አልተሰጠም (No description provided).'}
           </p>
        </div>

        {/* Chapter List Section */}
        <div className="space-y-6">
           <div className="flex items-center justify-between">
             <h2 className="text-xs font-black uppercase tracking-[0.3em] text-[#f2994a]">ምዕራፎች (Chapters)</h2>
           </div>
           <ChapterList storyId={id as string} />
        </div>
      </main>

      {/* Sticky Action Button */}
      <div className="fixed bottom-0 left-0 right-0 p-6 glass-nav border-t border-white/5 flex gap-4 z-50">
         <button className="flex-1 py-4 bg-[#f2994a] text-black font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-[#f2994a]/20 flex items-center justify-center gap-2 active:scale-95 transition-all">
           <Play size={16} fill="black" /> ማንበብ ጀምር (Start Reading)
         </button>
      </div>
    </div>
  );
}
