'use client';

import { motion } from 'framer-motion';
import DiscoveryFeed from '@/components/reader/DiscoveryFeed';
import BottomNav from '@/components/reader/BottomNav';
import { useAuth } from '@/context/AuthProvider';
import { Wallet, Sparkles, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function ReaderHome() {
  const { profile, balance, isLoading, session } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !session) {
      router.replace('/login');
    }
  }, [isLoading, session, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#f2994a] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!session) return null;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] relative pb-20">
      {/* Background Decor */}
      <div className="fixed inset-0 immersive-gradient pointer-events-none" />

      {/* Top Navigation Bar */}
      <header className="relative z-10 flex items-center justify-between px-6 py-4 glass-nav border-b border-white/5 sticky top-0">
        <div className="flex items-baseline gap-1">
          <span className="text-xl font-bold tracking-tighter text-[#f2994a]">ENGIDA</span>
          <span className="text-xs opacity-40 font-serif lowercase">v1.0</span>
        </div>

        <div className="flex items-center gap-4">
          <Link href="/wallet" className="bg-[#2a1d15] border border-[#f2994a]/30 px-3 py-1.5 rounded-full flex items-center gap-2 hover:scale-105 transition-transform">
            <div className="w-3 h-3 bg-[#f2994a] rounded-full shadow-[0_0_8px_#f2994a]" />
            <span className="text-[10px] font-black text-[#f2994a]">
              {isLoading ? '...' : balance} COINS
            </span>
          </Link>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-6 pt-6 space-y-12">
        
        {/* Hero Featured Story Section */}
        <section className="relative rounded-[2rem] overflow-hidden group h-[450px] md:h-[550px] shadow-2xl">
          <div 
            className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=1200')] bg-cover bg-center transition-transform duration-1000 group-hover:scale-110" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d0b0a] via-[#0d0b0a]/40 to-transparent" />
          
          <div className="absolute inset-0 p-8 md:p-12 flex flex-col justify-end items-start space-y-6">
            <motion.div 
               initial={{ opacity: 0, x: -20 }}
               animate={{ opacity: 1, x: 0 }}
               className="flex items-center gap-3"
            >
              <div className="px-3 py-1 bg-[#f2994a] text-black text-[9px] font-black uppercase tracking-widest rounded-full">
                Featured Serial
              </div>
              <span className="text-[10px] font-bold opacity-60 tracking-widest uppercase flex items-center gap-2">
                <Sparkles size={12} className="text-[#f2994a]" /> Romance / Mystery
              </span>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="max-w-xl space-y-4"
            >
              <h1 className="text-5xl md:text-7xl font-serif font-bold leading-[0.9] tracking-tight">
                The Red Soil of Despair
              </h1>
              <p className="text-lg md:text-xl opacity-80 font-serif leading-relaxed italic line-clamp-2">
                "In the heart of the Omo Valley, a secret buried for generations begins to surface..."
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="flex gap-4 w-full sm:w-auto"
            >
              <button className="flex-1 sm:flex-none px-10 py-4 bg-[#f2994a] text-black font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-[#f2994a]/20 active:scale-95 transition-all">
                Read Chapter 1
              </button>
            </motion.div>
          </div>
        </section>

        {/* Discovery Feed Section */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <TrendingUp size={20} className="text-[#f2994a]" />
              <h2 className="text-xs font-black uppercase tracking-[0.3em] text-white/50">Discovery Feed</h2>
            </div>
          </div>
          
          <DiscoveryFeed />
        </section>
      </main>

      <BottomNav />
    </div>
  );
}
