'use client';

import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { 
  User, Settings, Wallet, ShieldCheck, MessageCircle, 
  LogOut, ChevronRight, Award
} from 'lucide-react';
import BottomNav from '@/components/reader/BottomNav';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function ProfilePage() {
  const { profile, balance, isLoading: authLoading, isAdmin } = useAuth();
  const router = useRouter();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/login');
  }

  if (authLoading) return (
    <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">
      በመጫን ላይ...
    </div>
  );

  const menuItems = [
    { label: 'My Account', icon: User, desc: 'Personal details & preferences', href: '/profile/edit' },
    { label: 'Wallet & Coins', icon: Wallet, desc: `${balance} Coins available`, href: '/wallet' },
    { label: 'Support Bot', icon: MessageCircle, desc: 'Get help or report issues', href: 'https://t.me/EthioSupportBot', external: true },
  ];

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-32">
       <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-20" />

       <header className="relative z-10 p-6 flex justify-between items-center glass-nav border-b border-white/5 sticky top-0">
          <h1 className="text-xl font-bold tracking-tight text-[#f2994a]">My Profile</h1>
          <button className="p-2 hover:bg-white/5 rounded-full transition-colors active:scale-90">
             <Settings size={20} className="opacity-40" />
          </button>
       </header>

       <main className="relative z-10 p-6 space-y-10">
          <section className="bg-gradient-to-br from-[#1a1510] to-[#2a1d15] rounded-[2.5rem] p-8 border border-[#f2994a]/20 shadow-2xl space-y-8">
             <div className="flex flex-col items-center text-center space-y-4">
                <div className="w-24 h-24 rounded-full bg-[#f2994a]/10 border-2 border-[#f2994a]/30 p-1 relative">
                   <div className="w-full h-full rounded-full bg-[#2a1d15] flex items-center justify-center text-[#f2994a] text-3xl font-black">
                      {profile?.full_name?.charAt(0) || 'U'}
                   </div>
                   <div className="absolute bottom-0 right-0 w-8 h-8 bg-green-500 rounded-full border-4 border-[#1a1510] flex items-center justify-center">
                      <ShieldCheck size={12} className="text-black" />
                   </div>
                </div>
                <div>
                  <h2 className="text-2xl font-serif font-bold text-white uppercase tracking-tight">{profile?.full_name || 'Guest User'}</h2>
                  <p className="text-[10px] opacity-40 font-black uppercase tracking-widest mt-1">@{profile?.username || 'reader'}</p>
                </div>
             </div>
             <div className="grid grid-cols-2 gap-4">
                <div className="bg-black/20 p-4 rounded-2xl border border-white/5 text-center">
                   <p className="text-[8px] opacity-40 uppercase tracking-widest mb-1">Rank</p>
                   <p className="text-xs font-black text-white flex items-center justify-center gap-2">
                      <Award size={14} className="text-[#f2994a]" /> Elder Reader
                   </p>
                </div>
                <div className="bg-black/20 p-4 rounded-2xl border border-white/5 text-center">
                   <p className="text-[8px] opacity-40 uppercase tracking-widest mb-1">Status</p>
                   <div className="text-xs font-black text-green-400 flex items-center justify-center gap-2">
                      <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" /> {profile?.role || 'Reader'}
                   </div>
                </div>
             </div>
          </section>

          {isAdmin && (
            <Link href="/admin-dashboard" className="block bg-red-500/10 border border-red-500/20 p-6 rounded-3xl flex items-center justify-between group active:scale-95 transition-all">
               <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-red-500 rounded-2xl flex items-center justify-center text-white">
                     <ShieldCheck size={20} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-red-500">Admin Control Panel</h3>
                    <p className="text-[10px] opacity-40 uppercase tracking-widest">Manage platform content</p>
                  </div>
               </div>
               <ChevronRight size={20} className="text-red-500/40 group-hover:text-red-500" />
            </Link>
          )}

          <section className="space-y-3">
             {menuItems.map((item, i) => (
                <Link key={i} href={item.href} target={item.external ? '_blank' : undefined} rel={item.external ? 'noopener noreferrer' : undefined}
                  className="bg-white/5 border border-white/5 p-5 rounded-3xl flex items-center justify-between group active:scale-95 transition-all"
                >
                   <div className="flex items-center gap-5">
                      <div className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center text-[#f2994a]">
                         <item.icon size={20} />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold">{item.label}</h4>
                        <p className="text-[10px] opacity-40 uppercase tracking-widest">{item.desc}</p>
                      </div>
                   </div>
                   <ChevronRight size={20} className="text-white/10 group-hover:text-[#f2994a]" />
                </Link>
             ))}
          </section>

          <button
            onClick={handleLogout}
            className="w-full py-5 bg-white/5 border border-red-500/10 rounded-3xl text-red-500 font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-3 active:scale-95 transition-all"
          >
             <LogOut size={18} /> Sign Out Safely
          </button>
       </main>
       <BottomNav />
    </div>
  );
}
