'use client';

import { useState } from 'react';
import { useAuth } from '@/context/AuthProvider';
import { ChevronLeft, Wallet, Info, Coins, X } from 'lucide-react';
import BottomNav from '@/components/reader/BottomNav';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import TelebirrForm from '@/components/wallet/TelebirrForm';

const COIN_PACKAGES = [
  { id: 'p1', coins: 50, price: 50, label: 'Standard' },
  { id: 'p2', coins: 100, price: 100, label: 'Popular' },
  { id: 'p3', coins: 300, price: 300, label: 'Heavy Reader' },
  { id: 'p4', coins: 500, price: 500, label: 'Fanatic' },
];

export default function WalletPage() {
  const { balance, isLoading } = useAuth();
  const router = useRouter();
  const [selectedPackage, setSelectedPackage] = useState<typeof COIN_PACKAGES[0] | null>(null);

  const telebirrNumber = process.env.NEXT_PUBLIC_TELEBIRR_NUMBER || '0911000000';

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-20">
      <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-40" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center glass-nav border-b border-white/5">
        <button onClick={() => router.back()} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center">
          <ChevronLeft size={24} />
        </button>
        <div className="flex flex-col items-center">
          <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40">Your Wallet</span>
          <h1 className="font-serif font-bold italic">ዋሌት</h1>
        </div>
        <div className="w-10" />
      </header>

      <main className="relative z-10 p-6 space-y-8">
        {/* Balance Card */}
        <div className="bg-gradient-to-br from-[#1a1510] to-[#2a1d15] rounded-[2rem] p-8 border border-[#f2994a]/20 text-center space-y-4 shadow-2xl">
          <div className="w-16 h-16 bg-[#f2994a]/10 rounded-full flex items-center justify-center mx-auto text-[#f2994a]">
             <Coins size={32} />
          </div>
          <div>
            <p className="text-4xl font-black text-[#f2994a] tracking-tight">{isLoading ? '...' : balance}</p>
            <p className="text-[10px] font-bold uppercase tracking-[0.4em] opacity-40">Current Coin Balance</p>
          </div>
        </div>

        {/* Packages Grid */}
        <div className="space-y-4">
          <h2 className="text-xs font-black uppercase tracking-[0.3em] text-[#f2994a]">Coin Packages</h2>
          <div className="grid grid-cols-2 gap-4">
            {COIN_PACKAGES.map((pkg) => (
              <button
                key={pkg.id}
                onClick={() => setSelectedPackage(pkg)}
                className="bg-white/5 border border-white/5 rounded-2xl p-6 text-left hover:bg-white/10 hover:border-[#f2994a]/30 transition-all group"
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="text-2xl font-black text-[#f2994a]">{pkg.coins}</span>
                  <Coins size={16} className="text-[#f2994a]/40" />
                </div>
                <p className="text-[10px] font-bold uppercase tracking-widest opacity-40 mb-3">{pkg.label}</p>
                <div className="bg-[#2a1d15] py-2 px-3 rounded-xl border border-[#f2994a]/20 text-center font-black text-[10px] text-[#f2994a]">
                  {pkg.price} ETB
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-white/5 rounded-2xl p-6 border border-white/5 space-y-4 opacity-70">
          <div className="flex items-center gap-3 text-[#f2994a]">
            <Info size={16} />
            <h3 className="text-[10px] font-black uppercase tracking-widest">How to Recharge</h3>
          </div>
          <p className="text-xs leading-relaxed font-serif italic">
            "ቀጥታ በቴሌ ብር ወደ {telebirrNumber} ይላኩ። ከላኩ በኋላ የደረሰኝ ቁጥሩን እና ፎቶውን ከታች ባለው ቅጽ ይላኩ።"
          </p>
          <p className="text-xs leading-relaxed opacity-60">
            Send the corresponding ETB amount to Telebirr number <span className="text-white font-bold">{telebirrNumber}</span>. Then submit the transaction ID and screenshot below.
          </p>
        </div>
      </main>

      {/* Modal / Sheet for Payment Submission */}
      <AnimatePresence>
        {selectedPackage && (
          <>
            <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               onClick={() => setSelectedPackage(null)}
               className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="fixed bottom-0 left-0 right-0 z-[70] bg-[#0d0b0a] border-t border-white/10 rounded-t-[2.5rem] p-8 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-serif font-bold">Submit Payment</h2>
                  <p className="text-[10px] font-black uppercase tracking-widest text-[#f2994a]">
                    For {selectedPackage.coins} Coins ({selectedPackage.price} ETB)
                  </p>
                </div>
                <button onClick={() => setSelectedPackage(null)} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">
                   <X size={20} />
                </button>
              </div>

              <TelebirrForm 
                packageAmount={selectedPackage.coins} 
                onSuccess={() => setSelectedPackage(null)} 
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <BottomNav />
    </div>
  );
}
