'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { 
  BookOpen, 
  Clock, 
  Trash2, 
  Sparkles,
  BookMarked
} from 'lucide-react';
import BottomNav from '@/components/reader/BottomNav';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';

type LibraryStory = {
  id: string;
  story_id: string;
  last_read_at: string;
  stories: {
    id: string;
    title: string;
    cover_url: string;
    genre: string;
    author_id: string;
    profiles: {
      full_name: string;
    }
  }
};

export default function LibraryPage() {
  const { profile, isLoading: authLoading } = useAuth();
  const [readingList, setReadingList] = useState<LibraryStory[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchLibrary() {
      if (!profile) return;

      // In a real app, this would be a 'user_library' or 'reading_history' table
      // For now, we fetch stories to show a mock list or try to fetch from a presumed table
      const { data, error } = await (supabase
        .from('stories')
        .select('*, profiles(full_name)')
        .limit(5) as any);

      if (data) {
        setReadingList(data.map((s: any) => ({
          id: s.id,
          stories: s,
          last_read_at: new Date().toISOString()
        })));
      }
      setIsLoading(false);
    }

    if (!authLoading) fetchLibrary();
  }, [profile, authLoading]);

  if (authLoading || isLoading) return (
    <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">
      በመጫን ላይ...
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-32">
      <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-30" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center glass-nav border-b border-white/5 sticky top-0">
        <div className="flex items-center gap-3">
          <BookMarked size={20} className="text-[#f2994a]" />
          <h1 className="text-xl font-bold tracking-tight text-[#f2994a]">My Library</h1>
        </div>
        <div className="text-[10px] opacity-40 uppercase tracking-widest font-black">መጽሃፍት ቤት</div>
      </header>

      <main className="relative z-10 p-6 space-y-10">
        
        {/* Continue Reading Section */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-black uppercase tracking-[0.3em] text-white/50">Continue Reading</h2>
            <span className="text-[10px] text-[#f2994a] font-bold">See All</span>
          </div>

          <div className="space-y-4">
            {readingList.map((item) => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="group relative bg-white/5 border border-white/5 rounded-3xl p-4 flex gap-4 items-center hover:bg-white/10 transition-all"
              >
                <Link href={`/story/${item.stories.id}`} className="absolute inset-0 z-0" />
                
                <div className="w-20 h-28 bg-[#1a1510] rounded-2xl overflow-hidden relative shadow-lg flex-shrink-0">
                  {item.stories.cover_url ? (
                    <Image 
                      src={item.stories.cover_url} 
                      alt={item.stories.title} 
                      fill 
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                       <BookOpen size={24} className="opacity-20" />
                    </div>
                  )}
                </div>

                <div className="flex-1 space-y-2 py-1">
                  <div className="space-y-0.5">
                    <h3 className="text-sm font-bold text-white line-clamp-1 group-hover:text-[#f2994a] transition-colors">
                      {item.stories.title}
                    </h3>
                    <p className="text-[10px] opacity-40 font-serif italic">
                      by {item.stories.profiles?.full_name}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5 text-[9px] font-black uppercase tracking-widest text-[#f2994a]">
                      <Clock size={10} /> 45% Read
                    </div>
                  </div>

                  <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-[#f2994a] w-[45%]" />
                  </div>
                </div>

                <button className="relative z-10 p-2 text-white/10 hover:text-red-500 transition-colors">
                   <Trash2 size={16} />
                </button>
              </motion.div>
            ))}

            {readingList.length === 0 && (
              <div className="text-center py-20 border-2 border-dashed border-white/5 rounded-[2rem]">
                <Sparkles size={32} className="mx-auto mb-4 opacity-10" />
                <p className="text-sm opacity-20 italic font-serif">Your library is empty. Start your journey today!</p>
              </div>
            )}
          </div>
        </section>

        {/* Saved for Later */}
        <section className="space-y-6">
           <h2 className="text-xs font-black uppercase tracking-[0.3em] text-white/50">Saved Stories</h2>
           <div className="grid grid-cols-2 gap-4">
              {readingList.slice(0, 2).map((item) => (
                <Link key={`saved-${item.id}`} href={`/story/${item.stories.id}`} className="space-y-3">
                   <div className="aspect-[3/4] rounded-3xl overflow-hidden relative shadow-xl">
                      {item.stories.cover_url && (
                        <Image 
                          src={item.stories.cover_url} 
                          alt={item.stories.title} 
                          fill 
                          className="object-cover" 
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                   </div>
                   <h4 className="text-[10px] font-bold truncate px-1">{item.stories.title}</h4>
                </Link>
              ))}
           </div>
        </section>

      </main>

      {/* Bottom Nav Bar (Duplicate for UX consistency) */}
      <BottomNav />
    </div>
  );
}
