'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import { 
  Users, 
  BookText, 
  CreditCard, 
  TrendingUp, 
  ShieldCheck,
  ChevronRight,
  AlertCircle,
  Clock,
} from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default function AdminDashboard() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const router = useRouter();
  
  const [stats, setStats] = useState({
    users: 0,
    stories: 0,
    pendingPayments: 0,
    revenue: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !isAdmin) router.push('/home');
  }, [authLoading, isAdmin, router]);

  useEffect(() => {
    async function fetchStats() {
      if (!isAdmin) return;

      const [usersRes, storiesRes, paymentsRes, revenueRes] = await Promise.all([
        supabase.from('profiles').select('id', { count: 'exact', head: true }),
        supabase.from('stories').select('id', { count: 'exact', head: true }),
        supabase.from('transactions').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
        supabase.from('transactions').select('amount').eq('status', 'completed').eq('type', 'deposit')
      ]);

      setStats({
        users: usersRes.count || 0,
        stories: storiesRes.count || 0,
        pendingPayments: paymentsRes.count || 0,
        revenue: (revenueRes.data || []).reduce((acc, curr) => acc + (curr as any).amount, 0)
      });
      setIsLoading(false);
    }

    if (!authLoading && isAdmin) fetchStats();
  }, [authLoading, isAdmin]);

  if (authLoading || isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ (Admin)...</div>;

  const adminModules = [
    { 
      name: 'Payments', 
      desc: 'Verify Telebirr transactions', 
      icon: CreditCard, 
      href: '/payments', 
      count: stats.pendingPayments,
      color: 'text-blue-400'
    },
    { 
      name: 'Stories', 
      desc: 'Approve & Curation chapters', 
      icon: BookText, 
      href: '/stories', 
      color: 'text-[#f2994a]'
    },
    { 
      name: 'Monetization', 
      desc: 'Partner program requests', 
      icon: ShieldCheck, 
      href: '/monetization', 
      color: 'text-green-400'
    }
  ];

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-20">
      <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-20" />

      <header className="relative z-10 p-6 glass-nav border-b border-white/5 sticky top-0 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-black tracking-tighter text-[#f2994a]">Control Center</h1>
          <p className="text-[10px] opacity-40 uppercase tracking-widest font-black">የአስተዳዳሪ ክፍል</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/30 rounded-full">
           <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
           <span className="text-[9px] font-black text-red-500 uppercase tracking-widest">Live Admin</span>
        </div>
      </header>

      <main className="relative z-10 p-6 space-y-10 text-center">
        <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
           {[
             { label: 'Total Users', val: stats.users, icon: Users },
             { label: 'Total Stories', val: stats.stories, icon: BookText },
             { label: 'Pending Pkts', val: stats.pendingPayments, icon: Clock, accent: stats.pendingPayments > 0 },
             { label: 'Total Revenue', val: `${stats.revenue} ETB`, icon: TrendingUp }
           ].map((kpi, i) => (
             <div key={i} className="bg-white/5 border border-white/5 p-4 rounded-2xl space-y-2">
                <kpi.icon size={16} className={kpi.accent ? 'text-red-400' : 'text-[#f2994a]'} />
                <p className="text-lg font-black truncate">{kpi.val}</p>
                <p className="text-[8px] opacity-40 uppercase tracking-widest">{kpi.label}</p>
             </div>
           ))}
        </section>

        <section className="space-y-4 text-left">
           <h2 className="text-xs font-black uppercase tracking-[0.3em] text-white/40">Admin Modules</h2>
           <div className="grid gap-3">
              {adminModules.map((mod, i) => (
                <Link 
                  key={i} 
                  href={mod.href}
                  className="group bg-white/5 border border-white/5 p-5 rounded-2xl flex items-center justify-between hover:bg-white/10 hover:border-[#f2994a]/30 transition-all"
                >
                  <div className="flex items-center gap-5">
                    <div className={`w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center ${mod.color}`}>
                       <mod.icon size={24} />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold">{mod.name}</h3>
                      <p className="text-xs opacity-40 italic">{mod.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    {mod.count ? (
                      <span className="bg-red-500 text-white text-[10px] font-black px-2 py-1 rounded-full">{mod.count}</span>
                    ) : null}
                    <ChevronRight size={20} className="text-white/10 group-hover:text-[#f2994a]" />
                  </div>
                </Link>
              ))}
           </div>
        </section>
      </main>
    </div>
  );
}
