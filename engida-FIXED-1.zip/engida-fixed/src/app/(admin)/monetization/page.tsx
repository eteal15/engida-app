'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import { 
  ChevronLeft, 
  Check, 
  X, 
  ShieldCheck, 
  AlertCircle,
  Clock,
  Star
} from 'lucide-react';
import { motion } from 'framer-motion';

type MonetizationRequest = {
  id: string;
  author_id: string;
  payout_method: string;
  payout_details: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  profiles: { 
    full_name: string; 
    telegram_id: string;
    // Assuming there's a way to join story counts or just fetch them separately
  };
};

export default function AdminMonetization() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const router = useRouter();
  
  const [requests, setRequests] = useState<MonetizationRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !isAdmin) router.push('/home');
  }, [authLoading, isAdmin, router]);

  const fetchRequests = async () => {
    // In a real app, we'd have a monetization_requests table. 
    // For this prototype, we'll fetch profiles who have >= 3 approved stories 
    // AND haven't been monetized yet, or use a placeholder system.
    // Let's assume a 'monetization_requests' table exists as per logic in Phase 8 instructions.
    
    const { data, error } = await (supabase
      .from('payouts') // Reusing/assuming table or using as proxy
      .select('*, profiles(full_name, telegram_id)')
      .eq('status', 'pending') as any);
    
    if (data) setRequests(data as any);
    setIsLoading(false);
  };

  useEffect(() => {
    if (isAdmin) fetchRequests();
  }, [isAdmin]);

  const handleAction = async (requestId: string, status: 'approved' | 'rejected') => {
    const { error } = await (supabase.from('payouts') as any)
      .update({ status } as any)
      .eq('id', requestId);

    if (!error) {
      alert(`Request ${status}!`);
      fetchRequests();
    }
  };

  if (authLoading || isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf]" id="admin_monetization_page">
      <header className="p-6 glass-nav border-b border-white/5 flex items-center gap-4 sticky top-0 z-20">
        <button onClick={() => router.push('/admin-dashboard')} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center">
          <ChevronLeft size={20} />
        </button>
        <div>
          <h1 className="text-xl font-bold font-serif text-green-400">Writer Monetization</h1>
          <p className="text-[10px] opacity-40 uppercase tracking-widest font-black">የጸሐፊዎች ገቢ ማረጋገጫ</p>
        </div>
      </header>

      <main className="p-6 space-y-8">
        
        {/* Helper Note */}
        <div className="bg-green-500/10 border border-green-500/20 rounded-3xl p-6 flex gap-4">
           <Star className="text-green-500 flex-shrink-0" size={20} />
           <p className="text-[10px] opacity-70 leading-relaxed font-serif italic">
             "እዚህ የሚታዩት ቢያንስ 3 ተቀባይነት ያገኙ ታሪኮችን ያሳተሙ እና የክፍያ ጥያቄ ያቀረቡ ጸሐፊዎች ናቸው።"
             <br /><br />
             Only writers with 3+ approved completed stories are eligible for monetization programs. Check their payment details carefully.
           </p>
        </div>

        <div className="space-y-4">
           {requests.map((req) => (
             <div key={req.id} className="bg-white/5 border border-white/5 rounded-3xl p-6 space-y-6">
                <div className="flex justify-between items-center">
                   <div>
                      <h4 className="text-sm font-bold">{req.profiles?.full_name}</h4>
                      <p className="text-[9px] opacity-40 uppercase font-black">TG ID: {req.profiles?.telegram_id}</p>
                   </div>
                   <div className="bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20">
                      <span className="text-[8px] font-black text-green-500 uppercase tracking-widest">Eligible</span>
                   </div>
                </div>

                <div className="bg-black/20 p-5 rounded-2xl border border-white/5 space-y-2">
                   <p className="text-[8px] opacity-40 uppercase tracking-widest">Telebirr Info</p>
                   <p className="text-xs font-serif italic">{req.payout_method}: {req.payout_details}</p>
                </div>

                <div className="flex gap-3">
                   <button 
                     onClick={() => handleAction(req.id, 'approved')}
                     className="flex-1 py-4 bg-green-500 text-black font-black text-[10px] uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all"
                   >
                     <Check size={16} /> Approve Writer
                   </button>
                   <button 
                     onClick={() => handleAction(req.id, 'rejected')}
                     className="flex-1 py-4 border border-red-500/20 text-red-500 font-black text-[10px] uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all"
                   >
                     <X size={16} /> Decline
                   </button>
                </div>
             </div>
           ))}

           {requests.length === 0 && (
             <div className="text-center py-20 opacity-20 italic font-serif text-sm">
                ምንም ጥያቄ አልቀረበም (No monetization requests)
             </div>
           )}
        </div>
      </main>
    </div>
  );
}
