'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import { 
  ChevronLeft, 
  Check, 
  X, 
  Eye, 
  CreditCard, 
  Loader2,
  ExternalLink,
  Smartphone
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';

type Transaction = {
  id: string;
  user_id: string;
  amount: number;
  reference_id: string;
  screenshot_url: string;
  status: 'pending' | 'completed' | 'rejected';
  created_at: string;
  profiles: { full_name: string; telegram_id: string };
};

export default function AdminPayments() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const router = useRouter();
  
  const [payments, setPayments] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [viewingImage, setViewingImage] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !isAdmin) router.push('/home');
  }, [authLoading, isAdmin, router]);

  const fetchPayments = async () => {
    const { data, error } = await (supabase
      .from('transactions')
      .select('*, profiles(full_name, telegram_id)')
      .eq('status', 'pending')
      .eq('type', 'deposit')
      .order('created_at', { ascending: true }) as any);
    
    if (data) setPayments(data as Transaction[]);
    setIsLoading(false);
  };

  useEffect(() => {
    if (isAdmin) fetchPayments();
  }, [isAdmin]);

  const handleAction = async (id: string, userId: string, amount: number, status: 'completed' | 'rejected') => {
    setProcessingId(id);
    try {
      if (status === 'completed') {
        // Atomic transaction simulation via RPC call
        const { error } = await (supabase.rpc as any)('approve_telebirr_payment', {
          target_transaction_id: id,
          target_user_id: userId,
          coin_amount: amount
        });
        if (error) throw error;
      } else {
        const { error } = await (supabase.from('transactions') as any)
          .update({ status: 'rejected' } as any)
          .eq('id', id);
        if (error) throw error;
      }
      
      alert(`Payment ${status}!`);
      fetchPayments();
    } catch (err: any) {
      console.error(err);
      alert(`Error: ${err.message}`);
    } finally {
      setProcessingId(null);
    }
  };

  if (authLoading || isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf]" id="admin_payments_page">
      <header className="p-6 glass-nav border-b border-white/5 flex items-center gap-4 sticky top-0 z-20">
        <button onClick={() => router.push('/admin-dashboard')} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center">
          <ChevronLeft size={20} />
        </button>
        <div>
          <h1 className="text-xl font-bold font-serif italic text-[#f2994a]">Payment Verification</h1>
          <p className="text-[10px] opacity-40 uppercase tracking-widest font-black">የክፍያ ማረጋገጫ</p>
        </div>
      </header>

      <main className="p-6">
        <div className="space-y-4">
          {payments.map((pay) => (
            <motion.div 
              layout
              key={pay.id}
              className="bg-white/5 border border-white/5 rounded-3xl p-6 space-y-6"
            >
              <div className="flex justify-between items-start">
                <div className="flex gap-4 items-center">
                   <div className="w-12 h-12 bg-[#2a1d15] rounded-2xl flex items-center justify-center text-[#f2994a]">
                      <Smartphone size={24} />
                   </div>
                   <div>
                     <h4 className="text-sm font-bold">{pay.profiles?.full_name}</h4>
                     <p className="text-[10px] opacity-40 uppercase tracking-widest">ID: {pay.profiles?.telegram_id}</p>
                   </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-black text-[#f2994a]">{pay.amount} Coins</p>
                  <p className="text-[10px] opacity-40 uppercase tracking-widest font-black">Requested Pk</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div className="bg-black/20 p-4 rounded-2xl border border-white/5">
                    <p className="text-[8px] opacity-40 uppercase tracking-widest mb-1">Telebirr Ref ID</p>
                    <p className="text-xs font-mono font-bold text-white tracking-widest">{pay.reference_id}</p>
                 </div>
                 <button 
                   onClick={() => setViewingImage(pay.screenshot_url)}
                   className="flex items-center justify-center gap-2 bg-white/5 p-4 rounded-2xl border border-white/5 text-xs font-black uppercase tracking-widest hover:bg-white/10 transition-colors"
                 >
                    <Eye size={16} /> View Screenshot
                 </button>
              </div>

              <div className="flex gap-3 pt-2">
                 <button 
                   disabled={!!processingId}
                   onClick={() => handleAction(pay.id, pay.user_id, pay.amount, 'completed')}
                   className="flex-1 py-4 bg-green-500 text-black font-black text-xs uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
                 >
                   {processingId === pay.id ? <Loader2 className="animate-spin" size={16} /> : <Check size={16} />} Approve
                 </button>
                 <button 
                   disabled={!!processingId}
                   onClick={() => handleAction(pay.id, pay.user_id, pay.amount, 'rejected')}
                   className="flex-1 py-4 border border-red-500/20 text-red-500 font-black text-xs uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
                 >
                    <X size={16} /> Reject
                 </button>
              </div>
            </motion.div>
          ))}

          {payments.length === 0 && (
            <div className="text-center py-20 opacity-20 italic font-serif text-sm">
               ያልተረጋገጠ ክፍያ የለም (No pending payments)
            </div>
          )}
        </div>
      </main>

      {/* Image Modal */}
      <AnimatePresence>
        {viewingImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black flex flex-col p-6"
          >
            <button 
              onClick={() => setViewingImage(null)}
              className="self-end w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mb-6"
            >
              <X size={24} />
            </button>
            <div className="flex-1 relative w-full">
               <Image 
                  src={viewingImage} 
                  alt="Receipt" 
                  fill 
                  className="object-contain"
                  referrerPolicy="no-referrer"
               />
            </div>
            <div className="p-6 text-center text-[10px] font-black uppercase tracking-widest opacity-40">
               Verify Reference ID and Amount before approving
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
