'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import { BookOpen, Mail, Lock, Eye, EyeOff, Loader2, UserPlus } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<'Reader' | 'Writer'>('Reader');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError(error.message);
    } else {
      router.push('/home');
    }
    setIsLoading(false);
  }

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName, role },
      },
    });
    if (error) {
      setError(error.message);
    } else if (data.user) {
      // Upsert profile with chosen role
      await supabase.from('profiles').upsert({
        id: data.user.id,
        full_name: fullName,
        role,
      });
      setSuccessMsg('Account created! Please check your email to confirm, then login.');
      setMode('login');
    }
    setIsLoading(false);
  }

  return (
    <div className="min-h-screen bg-[#0d0b0a] flex flex-col items-center justify-center px-6 relative overflow-hidden">
      {/* Background glow */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#f2994a]/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-[#3a2012]/40 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-[#f2994a]/20 rounded-2xl flex items-center justify-center border border-[#f2994a]/30">
              <BookOpen size={24} className="text-[#f2994a]" />
            </div>
          </div>
          <h1 className="text-3xl font-black text-[#f2994a] tracking-tighter">ENGIDA</h1>
          <p className="text-[#e0d8cf]/50 text-sm mt-1">እንግዳ · Ethiopian Storytelling</p>
        </div>

        {/* Card */}
        <div className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm">
          {/* Tabs */}
          <div className="flex rounded-2xl bg-black/30 p-1 mb-8">
            <button
              onClick={() => { setMode('login'); setError(''); setSuccessMsg(''); }}
              className={`flex-1 py-2 text-sm font-bold rounded-xl transition-all ${
                mode === 'login'
                  ? 'bg-[#f2994a] text-black shadow'
                  : 'text-[#e0d8cf]/50 hover:text-[#e0d8cf]'
              }`}
            >
              ግባ (Login)
            </button>
            <button
              onClick={() => { setMode('signup'); setError(''); setSuccessMsg(''); }}
              className={`flex-1 py-2 text-sm font-bold rounded-xl transition-all ${
                mode === 'signup'
                  ? 'bg-[#f2994a] text-black shadow'
                  : 'text-[#e0d8cf]/50 hover:text-[#e0d8cf]'
              }`}
            >
              ተመዝገብ (Sign Up)
            </button>
          </div>

          <form onSubmit={mode === 'login' ? handleLogin : handleSignup} className="space-y-5">
            {mode === 'signup' && (
              <>
                <div>
                  <label className="text-xs text-[#e0d8cf]/60 mb-2 block">ሙሉ ስም (Full Name)</label>
                  <div className="flex items-center bg-black/30 border border-white/10 rounded-xl px-4 h-12">
                    <UserPlus size={16} className="text-[#f2994a]/60 mr-3 shrink-0" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      placeholder="Your full name"
                      required
                      className="bg-transparent text-[#e0d8cf] text-sm flex-1 outline-none placeholder:text-white/20"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-[#e0d8cf]/60 mb-2 block">እኔ ነኝ (I am a)</label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['Reader', 'Writer'] as const).map(r => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={`py-3 rounded-xl text-sm font-bold border transition-all ${
                          role === r
                            ? 'bg-[#f2994a]/20 border-[#f2994a] text-[#f2994a]'
                            : 'bg-black/20 border-white/10 text-[#e0d8cf]/50'
                        }`}
                      >
                        {r === 'Reader' ? '📚 አንባቢ' : '✍️ ጸሐፊ'}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="text-xs text-[#e0d8cf]/60 mb-2 block">ኢሜይል (Email)</label>
              <div className="flex items-center bg-black/30 border border-white/10 rounded-xl px-4 h-12">
                <Mail size={16} className="text-[#f2994a]/60 mr-3 shrink-0" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  required
                  className="bg-transparent text-[#e0d8cf] text-sm flex-1 outline-none placeholder:text-white/20"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-[#e0d8cf]/60 mb-2 block">የይለፍ ቃል (Password)</label>
              <div className="flex items-center bg-black/30 border border-white/10 rounded-xl px-4 h-12">
                <Lock size={16} className="text-[#f2994a]/60 mr-3 shrink-0" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  minLength={6}
                  className="bg-transparent text-[#e0d8cf] text-sm flex-1 outline-none placeholder:text-white/20"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}>
                  {showPassword
                    ? <EyeOff size={16} className="text-white/30" />
                    : <Eye size={16} className="text-white/30" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
                {error}
              </div>
            )}
            {successMsg && (
              <div className="bg-green-500/10 border border-green-500/30 rounded-xl px-4 py-3 text-green-400 text-sm">
                {successMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-12 bg-[#f2994a] hover:bg-[#e08838] text-black font-black rounded-xl transition-all disabled:opacity-60 flex items-center justify-center gap-2 text-sm"
            >
              {isLoading && <Loader2 size={16} className="animate-spin" />}
              {mode === 'login' ? 'ግባ (Login)' : 'ተመዝገብ (Create Account)'}
            </button>
          </form>
        </div>

        <p className="text-center text-[#e0d8cf]/30 text-xs mt-6">
          By signing up, you agree to our Terms of Service
        </p>
      </div>
    </div>
  );
}
