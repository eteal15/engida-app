'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import type { Session, User } from '@supabase/supabase-js';
import { Database } from '@/types/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  balance: number;
  isLoading: boolean;
  isAdmin: boolean;
  isWriter: boolean;
  refetchBalance: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [balance, setBalance] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  async function fetchProfileAndWallet(userId: string) {
    const [profileRes, walletRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', userId).single(),
      supabase.from('coin_wallets').select('balance').eq('user_id', userId).single(),
    ]);
    if (profileRes.data) setProfile(profileRes.data as Profile);
    if (walletRes.data) setBalance((walletRes.data as { balance: number }).balance);
  }

  async function refetchBalance() {
    if (!session?.user?.id) return;
    const { data } = await supabase
      .from('coin_wallets')
      .select('balance')
      .eq('user_id', session.user.id)
      .single();
    if (data) setBalance((data as { balance: number }).balance);
  }

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) {
        fetchProfileAndWallet(session.user.id).finally(() => setIsLoading(false));
      } else {
        setIsLoading(false);
      }
    });

    // Listen for auth changes (login, logout)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) {
        fetchProfileAndWallet(session.user.id);
      } else {
        setProfile(null);
        setBalance(0);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const value: AuthContextType = {
    user: session?.user ?? null,
    profile,
    balance,
    isLoading,
    isAdmin: profile?.role === 'Admin',
    isWriter: profile?.role === 'Writer',
    refetchBalance,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
