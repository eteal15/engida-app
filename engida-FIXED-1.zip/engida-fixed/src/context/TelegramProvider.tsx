'use client';

import { type PropsWithChildren } from 'react';

// Simplified TelegramProvider - wraps children without crashing
// outside of actual Telegram environment
export function TelegramProvider({ children }: PropsWithChildren) {
  return <>{children}</>;
}
