'use client';

import { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/context/AuthProvider';
import { Camera, CheckCircle2, Loader2, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TelebirrFormProps {
  packageAmount: number;
  onSuccess: () => void;
}

export default function TelebirrForm({ packageAmount, onSuccess }: TelebirrFormProps) {
  const { profile } = useAuth();
  const [refId, setRefId] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !file || !refId) return;

    setIsUploading(true);
    setError(null);

    try {
      // 1. Upload Screenshot to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${profile.id}-${Date.now()}.${fileExt}`;
      const filePath = `payments/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('payouts') // Reusing/assuming a bucket or should create one. Using 'payouts' for now or 'receipts'
        .upload(filePath, file);

      if (uploadError) throw new Error('የምስል ጭነት አልተሳካም (Image upload failed)');

      // 2. Create Pending Transaction record
      const { error: dbError } = await supabase
        .from('transactions')
        .insert({
          user_id: profile.id,
          type: 'deposit',
          amount: packageAmount,
          reference_id: refId,
          screenshot_url: filePath,
          status: 'pending',
          metadata: { package: `${packageAmount} Coins` }
        } as any);

      if (dbError) throw dbError;

      setIsSuccess(true);
      setTimeout(() => {
        onSuccess();
      }, 3000);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'ስህተት ተፈጥሯል (An error occurred)');
    } finally {
      setIsUploading(false);
    }
  };

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="p-8 text-center space-y-4"
      >
        <div className="w-16 h-16 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mx-auto">
          <CheckCircle2 size={32} />
        </div>
        <h3 className="text-xl font-bold font-serif">በግምገማ ላይ ነው...</h3>
        <p className="text-sm text-white/60">
          Your payment is under review. Coins will be added to your wallet shortly after verification.
        </p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-1">
      <div className="space-y-2">
        <label className="text-[10px] font-black uppercase tracking-widest text-white/40">
          Transaction Reference ID
        </label>
        <input
          required
          type="text"
          value={refId}
          onChange={(e) => setRefId(e.target.value)}
          placeholder="ይለጥፉ ወይም ይተይቡ (e.g. ABC123XYZ)"
          className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-4 text-sm focus:border-[#f2994a]/50 outline-none transition-all"
        />
      </div>

      <div className="space-y-2">
        <label className="text-[10px] font-black uppercase tracking-widest text-white/40">
          Screenshot Receipt
        </label>
        <div className="relative">
          <input
            required
            type="file"
            accept="image/*"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="absolute inset-0 opacity-0 cursor-pointer z-10"
          />
          <div className={`w-full h-32 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center gap-2 transition-all ${file ? 'border-[#f2994a]/50 bg-[#f2994a]/5' : 'border-white/10 bg-white/5'}`}>
            <Camera size={24} className={file ? 'text-[#f2994a]' : 'text-white/20'} />
            <span className="text-[10px] font-bold uppercase tracking-widest opacity-40">
              {file ? file.name : 'Upload Screenshot'}
            </span>
          </div>
        </div>
      </div>

      {error && (
        <p className="text-xs text-red-400 text-center font-bold">{error}</p>
      )}

      <button
        disabled={isUploading}
        className="w-full py-4 bg-[#f2994a] text-black font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-[#f2994a]/20 flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50"
      >
        {isUploading ? (
          <Loader2 size={16} className="animate-spin" />
        ) : (
          <>
            <Send size={16} /> Submit for Review
          </>
        )}
      </button>
    </form>
  );
}
