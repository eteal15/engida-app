'use client';

import { useState, useEffect, useCallback } from 'react';
import { Search, Filter, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { Database } from '@/types/database.types';
import StoryCard from './StoryCard';
import { motion, AnimatePresence } from 'framer-motion';

type Story = Database['public']['Tables']['stories']['Row'];

const GENRES = [
  'All', 'Romance', 'Dark Romance', 'Thriller', 'Mystery', 
  'Comedy', 'Spiritual', 'Horror', 'Adventure', 
  'Historical', 'Drama', 'Crime', 'Fantasy'
];

export default function DiscoveryFeed() {
  const [stories, setStories] = useState<Story[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const fetchStories = useCallback(async (isNewSearch = false) => {
    setIsLoading(true);
    const currentPage = isNewSearch ? 0 : page;
    const from = currentPage * 12;
    const to = from + 11;

    try {
      let query = supabase
        .from('stories')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .range(from, to);

      if (searchTerm) {
        query = query.ilike('title', `%${searchTerm}%`);
      }

      if (selectedGenre !== 'All') {
        query = query.eq('genre', selectedGenre);
      }

      const { data, error } = await query;

      if (error) throw error;

      if (isNewSearch) {
        setStories(data || []);
      } else {
        setStories(prev => [...prev, ...(data || [])]);
      }

      setHasMore(data?.length === 12);
      if (!isNewSearch) setPage(prev => prev + 1);
      
    } catch (error) {
      console.error('Error fetching stories:', error);
    } finally {
      setIsLoading(false);
    }
  }, [searchTerm, selectedGenre, page]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(0);
      fetchStories(true);
    }, 500);

    return () => clearTimeout(timer);
  }, [searchTerm, selectedGenre]);

  return (
    <div className="space-y-8">
      {/* Search and Filters Shell */}
      <div className="sticky top-0 z-20 py-4 bg-[#0d0b0a]/80 backdrop-blur-md space-y-4">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 group-focus-within:text-[#f2994a] transition-colors" />
          <input
            type="text"
            placeholder="ታሪክ ፈልግ... (Search stories...)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-[#f2994a]/50 transition-all placeholder:text-white/20"
          />
        </div>

        <div className="flex overflow-x-auto gap-2 pb-2 scrollbar-none no-scrollbar">
          {GENRES.map((genre) => (
            <button
              key={genre}
              onClick={() => setSelectedGenre(genre)}
              className={`px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest whitespace-nowrap border transition-all ${
                selectedGenre === genre
                  ? 'bg-[#f2994a] text-black border-[#f2994a]'
                  : 'bg-white/5 text-white/40 border-white/5 hover:bg-white/10'
              }`}
            >
              {genre}
            </button>
          ))}
        </div>
      </div>

      {/* Results Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
        <AnimatePresence mode="popLayout">
          {stories.map((story) => (
            <StoryCard key={story.id} story={story} />
          ))}
        </AnimatePresence>
      </div>

      {/* Loading & Empty States */}
      {isLoading && (
        <div className="flex justify-center py-10">
          <Loader2 className="w-8 h-8 text-[#f2994a] animate-spin" />
        </div>
      )}

      {!isLoading && stories.length === 0 && (
        <div className="text-center py-20 space-y-4">
          <p className="text-white/40 font-serif italic text-lg">ምንም ታሪክ አልተገኘም</p>
          <p className="text-xs text-white/20 uppercase tracking-[0.2em]">Try a different search or genre</p>
        </div>
      )}

      {/* Load More Trigger */}
      {!isLoading && hasMore && stories.length > 0 && (
        <div className="flex justify-center pt-8 pb-12">
          <button
            onClick={() => fetchStories()}
            className="px-8 py-3 bg-white/5 border border-white/10 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-all"
          >
            Load More Stories
          </button>
        </div>
      )}
    </div>
  );
}
