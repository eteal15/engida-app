'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Eye, Heart, Lock } from 'lucide-react';
import { motion } from 'motion/react';
import { Database } from '@/types/database.types';

type Story = Database['public']['Tables']['stories']['Row'];

interface StoryCardProps {
  story: Story;
}

export default function StoryCard({ story }: StoryCardProps) {
  // Check if it's premium based on some logic or metadata (placeholder for now)
  const isPremium = true; 

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      whileHover={{ y: -4 }}
      className="group relative"
    >
      <Link href={`/story/${story.id}`} className="block">
        <div className="relative aspect-[3/4] rounded-2xl overflow-hidden card-blur border border-white/5 bg-gray-900">
          {story.cover_url ? (
            <Image
              src={story.cover_url}
              alt={story.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-110"
              sizes="(max-width: 768px) 50vw, 33vw"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900">
              <span className="text-white/20 font-serif italic">መጽሐፍ</span>
            </div>
          )}
          
          {/* Overlay Gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />

          {/* Premium Tag */}
          {isPremium && (
            <div className="absolute top-3 left-3 px-2 py-1 bg-[#f2994a] text-black text-[9px] font-black uppercase rounded shadow-lg">
              PREMIUM
            </div>
          )}

          {/* Stats Overlay */}
          <div className="absolute bottom-3 left-3 right-3 flex justify-between items-center text-white/90">
             <div className="flex gap-3">
               <span className="flex items-center gap-1 text-[10px] font-medium">
                 <Eye size={12} className="text-[#f2994a]" /> {(story.views_count / 1000).toFixed(1)}k
               </span>
               <span className="flex items-center gap-1 text-[10px] font-medium">
                 <Heart size={12} className="text-[#f2994a]" /> {(story.likes_count / 1000).toFixed(1)}k
               </span>
             </div>
          </div>
        </div>

        <div className="mt-3 space-y-1">
          <h3 className="font-serif font-bold text-sm line-clamp-1 group-hover:text-[#f2994a] transition-colors">
            {story.title}
          </h3>
          <p className="text-[10px] text-white/40 uppercase tracking-widest font-medium">
            By Author
          </p>
        </div>
      </Link>
    </motion.div>
  );
}
