'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Database } from '@/types/database.types';
import { useAuth } from '@/context/AuthProvider';
import { Lock, Unlock, Play, Coffee, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { unlockChapter } from '@/actions/unlockChapter';

type Chapter = Database['public']['Tables']['chapters']['Row'];
type UnlockRecord = Database['public']['Tables']['chapter_unlocks']['Row'];

interface ChapterListProps {
  storyId: string;
}

export default function ChapterList({ storyId }: ChapterListProps) {
  const { profile, balance } = useAuth();
  const router = useRouter();
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [unlocks, setUnlocks] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [isUnlocking, setIsUnlocking] = useState<string | null>(null);

  useEffect(() => {
    async function fetchData() {
      if (!storyId) return;

      const [chaptersRes, unlocksRes] = await Promise.all([
        (supabase
          .from('chapters')
          .select('*')
          .eq('story_id', storyId)
          .order('chapter_number', { ascending: true }) as any),
        profile ? 
          (supabase
            .from('chapter_unlocks')
            .select('chapter_id')
            .eq('user_id', profile.id) as any) : 
          Promise.resolve({ data: [] })
      ]);

      const chaptersData = chaptersRes.data as Chapter[];
      const unlocksData = (unlocksRes.data || []) as { chapter_id: string }[];

      if (chaptersData) setChapters(chaptersData);
      if (unlocksData) {
        setUnlocks(new Set(unlocksData.map(u => u.chapter_id)));
      }
      setIsLoading(false);
    }

    fetchData();
  }, [storyId, profile]);

  const isChapterUnlocked = (chapter: Chapter) => {
    if (!chapter.is_locked || chapter.chapter_number <= 3) return true;
    return unlocks.has(chapter.id);
  };

  const handleUnlock = async (chapter: Chapter) => {
    if (!profile) return alert('Please log in through Telegram');
    
    if (balance < chapter.coin_price) {
      if (confirm(`Insufficient balance. Current: ${balance} Coins. Would you like to recharge?`)) {
        router.push('/wallet');
      }
      return;
    }

    if (!confirm(`Unlock "${chapter.title}" for ${chapter.coin_price} coins?`)) return;

    setIsUnlocking(chapter.id);
    try {
      await unlockChapter(chapter.id);
      setUnlocks(prev => new Set([...Array.from(prev), chapter.id]));
      alert('Chapter unlocked successfully!');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsUnlocking(null);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => (
          <div key={i} className="h-16 w-full bg-white/5 rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {chapters.map((chapter) => {
        const unlocked = isChapterUnlocked(chapter);
        
        return (
          <div key={chapter.id} className="group">
            {unlocked ? (
              <Link
                href={`/story/${storyId}/read/${chapter.id}`}
                className="flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-2xl hover:bg-white/10 hover:border-[#f2994a]/30 transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-[#f2994a]/10 flex items-center justify-center text-[#f2994a]">
                    <span className="text-xs font-black">{chapter.chapter_number}</span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white/90">{chapter.title}</h4>
                    <p className="text-[10px] text-white/40 uppercase tracking-widest">ተከፍቷል • Unlocked</p>
                  </div>
                </div>
                <Play size={16} className="text-[#f2994a] opacity-0 group-hover:opacity-100 transition-opacity" />
              </Link>
            ) : (
              <button
                disabled={isUnlocking === chapter.id}
                onClick={() => handleUnlock(chapter)}
                className="w-full flex items-center justify-between p-4 bg-black/40 border border-dashed border-white/10 rounded-2xl cursor-pointer hover:bg-white/5 transition-all disabled:opacity-50"
              >
                <div className="flex items-center gap-4 opacity-50">
                  <div className="w-10 h-10 rounded-xl bg-gray-800 flex items-center justify-center">
                    {isUnlocking === chapter.id ? (
                      <Loader2 size={16} className="animate-spin text-[#f2994a]" />
                    ) : (
                      <Lock size={16} />
                    )}
                  </div>
                  <div className="text-left">
                    <h4 className="text-sm font-bold">{chapter.title}</h4>
                    <p className="text-[10px] uppercase tracking-widest">ምዕራፍ {chapter.chapter_number}</p>
                  </div>
                </div>
                <div className="bg-[#2a1d15] px-3 py-1.5 rounded-full border border-[#f2994a]/30 flex items-center gap-2">
                   <span className="text-[10px] font-black text-[#f2994a]">{chapter.coin_price} COINS</span>
                </div>
              </button>
            )}
          </div>
        );
      })}
      
      {chapters.length === 0 && (
        <div className="text-center py-10 opacity-40 italic font-serif">
          ገና ምዕራፎች አልተጨመሩም (No chapters added yet)
        </div>
      )}
    </div>
  );
}
