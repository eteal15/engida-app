'use client';

import { TrendingUp, BookMarked, Search, Wallet, User } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function BottomNav() {
  const pathname = usePathname();

  const navItems = [
    { label: 'Home', href: '/home', icon: TrendingUp },
    { label: 'Library', href: '/library', icon: BookMarked },
    { label: 'Search', href: '/search', icon: Search, isMain: true },
    { label: 'Earn', href: '/writer-dashboard', icon: Wallet },
    { label: 'Me', href: '/profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass-nav border-t border-white/5 px-8 pt-4 pb-8 flex justify-between items-center lg:hidden">
      {navItems.map((item) => {
        const isActive = pathname === item.href;
        
        if (item.isMain) {
          return (
            <Link 
              key={item.href}
              href={item.href} 
              className={`relative -top-4 w-12 h-12 bg-gradient-to-br from-[#f2994a] to-[#d47d2a] rounded-2xl shadow-lg shadow-[#f2994a]/30 flex items-center justify-center text-black active:scale-90 transition-transform ${isActive ? 'ring-2 ring-[#f2994a] ring-offset-4 ring-offset-[#0d0b0a]' : ''}`}
            >
              <item.icon size={24} />
            </Link>
          );
        }

        return (
          <Link 
            key={item.href}
            href={item.href} 
            className={`flex flex-col items-center gap-1 transition-colors ${isActive ? 'text-[#f2994a]' : 'text-white/40 hover:text-white'}`}
          >
            <item.icon size={20} />
            <span className="text-[8px] font-black uppercase">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
