export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          username: string | null
          full_name: string | null
          avatar_url: string | null
          bio: string | null
          role: 'Reader' | 'Writer' | 'Admin'
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          username?: string | null
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          role?: 'Reader' | 'Writer' | 'Admin'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string | null
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          role?: 'Reader' | 'Writer' | 'Admin'
          created_at?: string
          updated_at?: string
        }
      }
      stories: {
        Row: {
          id: string
          author_id: string
          title: string
          description: string | null
          cover_url: string | null
          genre: string | null
          status: 'draft' | 'pending' | 'approved' | 'rejected'
          views_count: number
          likes_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          author_id: string
          title: string
          description?: string | null
          cover_url?: string | null
          genre?: string | null
          status?: 'draft' | 'pending' | 'approved' | 'rejected'
          views_count?: number
          likes_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          author_id?: string
          title?: string
          description?: string | null
          cover_url?: string | null
          genre?: string | null
          status?: 'draft' | 'pending' | 'approved' | 'rejected'
          views_count?: number
          likes_count?: number
          created_at?: string
          updated_at?: string
        }
      }
      chapters: {
        Row: {
          id: string
          story_id: string
          chapter_number: number
          title: string
          content: string
          is_locked: boolean
          coin_price: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          story_id: string
          chapter_number: number
          title: string
          content: string
          is_locked?: boolean
          coin_price?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          story_id?: string
          chapter_number?: number
          title?: string
          content?: string
          is_locked?: boolean
          coin_price?: number
          created_at?: string
          updated_at?: string
        }
      }
      coin_wallets: {
        Row: {
          user_id: string
          balance: number
          updated_at: string
        }
        Insert: {
          user_id: string
          balance?: number
          updated_at?: string
        }
        Update: {
          user_id?: string
          balance?: number
          updated_at?: string
        }
      }
      transactions: {
        Row: {
          id: string
          user_id: string
          type: 'deposit' | 'purchase' | 'payout'
          amount: number
          reference_id: string | null
          screenshot_url: string | null
          status: string
          metadata: Json | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          type: 'deposit' | 'purchase' | 'payout'
          amount: number
          reference_id?: string | null
          screenshot_url?: string | null
          status?: string
          metadata?: Json | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          type?: 'deposit' | 'purchase' | 'payout'
          amount?: number
          reference_id?: string | null
          screenshot_url?: string | null
          status?: string
          metadata?: Json | null
          created_at?: string
        }
      }
      chapter_unlocks: {
        Row: {
          id: string
          user_id: string
          chapter_id: string
          unlocked_at: string
        }
        Insert: {
          id?: string
          user_id: string
          chapter_id: string
          unlocked_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          chapter_id?: string
          unlocked_at?: string
        }
      }
      user_interactions: {
        Row: {
          id: string
          user_id: string
          story_id: string
          chapter_id: string | null
          type: 'like' | 'bookmark' | 'reading_history'
          last_position: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          story_id: string
          chapter_id?: string | null
          type: 'like' | 'bookmark' | 'reading_history'
          last_position?: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          story_id?: string
          chapter_id?: string | null
          type?: 'like' | 'bookmark' | 'reading_history'
          last_position?: number
          created_at?: string
        }
      }
    }
  }
}
