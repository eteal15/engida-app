'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Search as SearchIcon, Filter, BookOpen, ChevronRight, TrendingUp } from 'lucide-react';
import BottomNav from '@/components/reader/BottomNav';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';
import Image from 'next/image';

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.trim().length < 2) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    const { data, error } = await supabase
      .from('stories')
      .select('*, profiles(full_name)')
      .ilike('title', `%${query}%`)
      .eq('status', 'approved')
      .limit(10);

    if (data) setResults(data);
    setIsSearching(false);
  };

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-32">
       <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-20" />

       <header className="relative z-10 p-6 space-y-6 glass-nav border-b border-white/5 sticky top-0">
          <div className="flex items-center gap-3">
             <div className="flex-1 relative">
                <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={20} />
                <input 
                  type="text" 
                  placeholder="Search stories, authors..."
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-[#f2994a] transition-all"
                />
             </div>
             <button className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center text-white/40">
                <Filter size={20} />
             </button>
          </div>
       </header>

       <main className="relative z-10 p-6">
          <AnimatePresence mode="wait">
             {results.length > 0 ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-4"
                >
                   {results.map((story) => (
                      <Link 
                        key={story.id} 
                        href={`/story/${story.id}`}
                        className="bg-white/5 border border-white/5 rounded-3xl p-4 flex gap-4 items-center group hover:bg-white/10 transition-all"
                      >
                         <div className="w-16 h-20 bg-gray-800 rounded-xl overflow-hidden relative flex-shrink-0">
                            {story.cover_url && (
                               <Image 
                                 src={story.cover_url} 
                                 alt={story.title} 
                                 fill 
                                 className="object-cover"
                                 referrerPolicy="no-referrer"
                               />
                            )}
                         </div>
                         <div className="flex-1 space-y-1">
                            <h4 className="text-sm font-bold text-white group-hover:text-[#f2994a] transition-colors line-clamp-1">{story.title}</h4>
                            <p className="text-[10px] opacity-40 font-serif italic uppercase tracking-widest">by {story.profiles?.full_name}</p>
                            <div className="flex items-center gap-2">
                               <span className="text-[9px] font-black text-[#f2994a] uppercase tracking-widest bg-[#f2994a]/10 px-2 py-0.5 rounded-full">{story.genre}</span>
                            </div>
                         </div>
                         <ChevronRight size={20} className="text-white/10 group-hover:text-[#f2994a]" />
                      </Link>
                   ))}
                </motion.div>
             ) : searchQuery && !isSearching ? (
                <div className="text-center py-20 opacity-20 italic font-serif">
                   No stories found for "{searchQuery}"
                </div>
             ) : !searchQuery ? (
                <div className="space-y-10">
                   {/* Trending Searches */}
                   <section className="space-y-4">
                      <h3 className="text-[10px] font-black uppercase tracking-widest text-[#f2994a]">Trending Searches</h3>
                      <div className="flex flex-wrap gap-2">
                         {['Historical', 'Romance', 'Mystery', 'Crime', 'Addis Ababa', 'Ancient'].map((tag) => (
                            <button 
                              key={tag}
                              onClick={() => handleSearch(tag)}
                              className="px-4 py-2 bg-white/5 border border-white/10 rounded-full text-xs font-bold hover:bg-[#f2994a] hover:text-black transition-all"
                            >
                               {tag}
                            </button>
                         ))}
                      </div>
                   </section>

                   {/* Recommended for you */}
                   <section className="space-y-6">
                      <div className="flex items-center gap-3">
                         <TrendingUp size={18} className="text-[#f2994a]" />
                         <h3 className="text-[10px] font-black uppercase tracking-widest text-white/40">Recommended for you</h3>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                         {[1, 2].map((i) => (
                            <div key={i} className="space-y-3">
                               <div className="aspect-[3/4] rounded-3xl bg-white/5 animate-pulse" />
                               <div className="h-3 w-3/4 bg-white/5 rounded animate-pulse" />
                            </div>
                         ))}
                      </div>
                   </section>
                </div>
             ) : null}
          </AnimatePresence>
       </main>

       {/* Bottom Nav */}
       <BottomNav />
    </div>
  );
}
