'use client';

import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { useState, useEffect } from 'react';
import { 
  ChevronLeft, 
  User, 
  Camera, 
  Save, 
  Loader2 
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function ProfileEditPage() {
  const { profile, isLoading: authLoading } = useAuth();
  const [fullName, setFullName] = useState('');
  const [bio, setBio] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const router = useRouter();

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setBio(profile.bio || '');
    }
  }, [profile]);

  const handleSave = async () => {
    if (!profile) return;
    setIsSaving(true);
    
    try {
      const { error } = await (supabase
        .from('profiles') as any)
        .update({
          full_name: fullName,
          bio: bio,
        })
        .eq('id', profile.id);

      if (error) throw error;
      router.back();
    } catch (err) {
      console.error('Save error', err);
    } finally {
      setIsSaving(false);
    }
  };

  if (authLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf]">
      <header className="p-6 flex items-center gap-4 border-b border-white/5 sticky top-0 bg-[#0d0b0a] z-10">
        <button onClick={() => router.back()} className="p-2 -ml-2 text-[#f2994a]">
          <ChevronLeft size={24} />
        </button>
        <h1 className="text-xl font-bold">Edit Profile</h1>
      </header>

      <main className="p-6 space-y-8">
        <section className="flex flex-col items-center gap-4 py-8">
          <div className="relative">
            <div className="w-32 h-32 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-4xl font-black text-[#f2994a] overflow-hidden">
               {profile?.full_name?.charAt(0) || <User size={48} />}
            </div>
            <button className="absolute bottom-1 right-1 w-10 h-10 bg-[#f2994a] rounded-full flex items-center justify-center text-black shadow-lg">
               <Camera size={18} />
            </button>
          </div>
          <p className="text-[10px] opacity-40 uppercase tracking-widest font-black">Change Profile Picture</p>
        </section>

        <section className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-white/50 px-1">Full Name</label>
            <input 
              type="text" 
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm focus:border-[#f2994a] focus:outline-none transition-all"
              placeholder="Your full name"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-widest text-white/50 px-1">Bio</label>
            <textarea 
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm focus:border-[#f2994a] focus:outline-none transition-all min-h-[120px]"
              placeholder="Write a short bio..."
            />
          </div>
        </section>

        <button 
          onClick={handleSave}
          disabled={isSaving}
          className="w-full py-5 bg-[#f2994a] text-black font-black text-xs uppercase tracking-[0.2em] rounded-3xl flex items-center justify-center gap-3 active:scale-95 transition-all disabled:opacity-50"
        >
          {isSaving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
          Save Changes
        </button>
      </main>
    </div>
  );
}
