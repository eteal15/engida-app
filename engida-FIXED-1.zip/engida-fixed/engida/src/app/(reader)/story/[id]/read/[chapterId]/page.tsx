'use client';

import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Database } from '@/types/database.types';
import { useAuth } from '@/context/AuthProvider';
import { ChevronLeft, Settings, ChevronRight, Sun, Moon, Type } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Chapter = Database['public']['Tables']['chapters']['Row'];

export default function ReaderView() {
  const { id, chapterId } = useParams();
  const router = useRouter();
  const { profile } = useAuth();
  
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [nextChapterId, setNextChapterId] = useState<string | null>(null);
  const [prevChapterId, setPrevChapterId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');

  useEffect(() => {
    async function fetchChapterData() {
      setIsLoading(true);

      // 1. Fetch current chapter
      const { data: currentChapter, error: chapterError } = await (supabase
        .from('chapters')
        .select('*')
        .eq('id', chapterId)
        .single() as any);

      if (chapterError || !currentChapter) {
        console.error('Chapter not found');
        router.push(`/story/${id}`);
        return;
      }

      const chapterData = currentChapter as Chapter;

      // 2. Check Security / Lock status
      if (chapterData.is_locked && chapterData.chapter_number > 3) {
        if (!profile) {
          router.push(`/story/${id}`);
          return;
        }

        const { data: unlock } = await supabase
          .from('chapter_unlocks')
          .select('*')
          .eq('chapter_id', chapterId)
          .eq('user_id', profile.id)
          .single();

        if (!unlock) {
          router.push(`/story/${id}`);
          return;
        }
      }

      setChapter(chapterData);

      // 3. Find next and previous chapter IDs
      const { data: siblingChapters } = await (supabase
        .from('chapters')
        .select('id, chapter_number')
        .eq('story_id', id)
        .order('chapter_number', { ascending: true }) as any);

      if (siblingChapters) {
        const chaptersList = siblingChapters as { id: string; chapter_number: number }[];
        const index = chaptersList.findIndex(c => c.id === chapterId);
        if (index > 0) setPrevChapterId(chaptersList[index - 1].id);
        if (index < chaptersList.length - 1) setNextChapterId(chaptersList[index + 1].id);
      }

      setIsLoading(false);
      window.scrollTo(0, 0);
    }

    if (chapterId) fetchChapterData();
  }, [chapterId, id, profile, router]);

  const fontClasses = {
    sm: 'text-sm',
    base: 'text-base',
    lg: 'text-lg',
    xl: 'text-xl md:text-2xl'
  };

  if (isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]/50">በመጫን ላይ...</div>;
  if (!chapter) return null;

  return (
    <div className={`min-h-screen transition-colors duration-500 ${theme === 'dark' ? 'bg-[#0d0b0a] text-[#e0d8cf]' : 'bg-[#f5f0e6] text-[#2a1d15]'}`}>
      
      {/* Minimal Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 p-6 flex justify-between items-center bg-transparent backdrop-blur-sm`}>
        <button 
          onClick={() => router.push(`/story/${id}`)}
          className={`w-10 h-10 rounded-full flex items-center justify-center border ${theme === 'dark' ? 'border-white/10 bg-black/20' : 'border-black/5 bg-white/40'}`}
        >
          <ChevronLeft size={24} />
        </button>
        <div className="flex gap-2">
          <button 
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className={`w-10 h-10 rounded-full flex items-center justify-center border ${theme === 'dark' ? 'border-white/10 bg-black/20' : 'border-black/5 bg-white/40'}`}
          >
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button 
            className={`w-10 h-10 rounded-full flex items-center justify-center border ${theme === 'dark' ? 'border-white/10 bg-black/20' : 'border-black/5 bg-white/40'}`}
          >
            <Type size={18} />
          </button>
        </div>
      </header>

      {/* Chapter Content */}
      <main className="max-w-2xl mx-auto px-6 pt-32 pb-48">
        <div className="space-y-12">
          <div className="text-center space-y-2">
            <p className="text-[10px] font-black uppercase tracking-[0.4em] opacity-40">ምዕራፍ {chapter.chapter_number}</p>
            <h1 className="text-3xl font-serif font-bold tracking-tight">{chapter.title}</h1>
            <div className={`w-12 h-1 mx-auto rounded-full ${theme === 'dark' ? 'bg-[#f2994a]' : 'bg-[#d47d2a]'}`} />
          </div>

          <div 
            className={`font-serif leading-[1.8] tracking-wide break-words space-y-6 ${fontClasses[fontSize]}`}
            dangerouslySetInnerHTML={{ __html: chapter.content.replace(/\n/g, '<br/>') }}
          />
        </div>
      </main>

      {/* Bottom Sticky Controls */}
      <footer className={`fixed bottom-0 left-0 right-0 z-50 p-6 flex items-center gap-4 border-t ${theme === 'dark' ? 'bg-[#0d0b0a]/90 border-white/5' : 'bg-[#f5f0e6]/90 border-black/5'} backdrop-blur-md`}>
         <button 
           disabled={!prevChapterId}
           onClick={() => router.push(`/story/${id}/read/${prevChapterId}`)}
           className={`flex-1 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 border transition-all ${
             !prevChapterId 
               ? 'opacity-20 cursor-not-allowed border-transparent' 
               : theme === 'dark' ? 'border-white/10 hover:bg-white/5' : 'border-black/10 hover:bg-black/5'
           }`}
         >
           <ChevronLeft size={16} /> ያለፈው (Prev)
         </button>
         
         <button 
           disabled={!nextChapterId}
           onClick={() => router.push(`/story/${id}/read/${nextChapterId}`)}
           className={`flex-1 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${
             !nextChapterId 
               ? 'opacity-20 cursor-not-allowed border-transparent bg-gray-500' 
               : 'bg-[#f2994a] text-black shadow-lg shadow-[#f2994a]/20 active:scale-95'
           }`}
         >
           ቀጣይ (Next) <ChevronRight size={16} />
         </button>
      </footer>
    </div>
  );
}
