'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { Database } from '@/types/database.types';
import { 
  Plus, 
  BarChart3, 
  BookOpen, 
  Heart, 
  DollarSign, 
  ChevronRight,
  Clock,
} from 'lucide-react';
import Link from 'next/link';
import { motion } from 'motion/react';
import Image from 'next/image';

type Story = Database['public']['Tables']['stories']['Row'];

export default function WriterDashboard() {
  const { profile, balance, isLoading: authLoading } = useAuth();
  const [stories, setStories] = useState<Story[]>([]);
  const [activeTab, setActiveTab] = useState<'published' | 'pending' | 'draft'>('published');
  const [stats, setStats] = useState({ reads: 0, likes: 0, earnings: 0 });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchWriterData() {
      if (!profile) {
        setIsLoading(false);
        return;
      }

      try {
        const { data, error } = await (supabase.from('stories') as any)
          .select('*')
          .eq('author_id', profile.id)
          .order('created_at', { ascending: false });

        if (data) {
          const storiesData = data as Story[];
          setStories(storiesData);
          const totalReads = storiesData.reduce((acc, s) => acc + (s.views_count || 0), 0);
          const totalLikes = storiesData.reduce((acc, s) => acc + (s.likes_count || 0), 0);
          setStats({ reads: totalReads, likes: totalLikes, earnings: 0 }); 
        }
      } catch (err) {
        console.error('Error fetching writer data:', err);
      } finally {
        setIsLoading(false);
      }
    }

    if (!authLoading) fetchWriterData();
  }, [profile, authLoading]);

  const filteredStories = stories.filter(s => {
    if (activeTab === 'published') return s.status === 'approved';
    if (activeTab === 'pending') return s.status === 'pending';
    return s.status === 'draft';
  });

  const approvedCount = stories.filter(s => s.status === 'approved').length;
  const monetizationProgress = Math.min((approvedCount / 3) * 100, 100);

  if (authLoading || isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-32">
      <div className="fixed inset-0 immersive-gradient pointer-events-none opacity-30" />

      <header className="relative z-10 p-6 flex justify-between items-center glass-nav border-b border-white/5 sticky top-0">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#f2994a]">Writer Studio</h1>
          <p className="text-[10px] opacity-40 uppercase tracking-widest font-black">የጸሐፊዎች ክፍል</p>
        </div>
        <Link href="/story/edit/create" className="w-10 h-10 bg-[#f2994a] rounded-full flex items-center justify-center text-black shadow-lg shadow-[#f2994a]/20 active:scale-90 transition-transform">
          <Plus size={24} />
        </Link>
      </header>

      <main className="relative z-10 p-6 space-y-10">
        
        <section className="grid grid-cols-3 gap-3">
          <div className="bg-white/5 border border-white/5 p-4 rounded-2xl flex flex-col items-center gap-2">
            <BookOpen size={16} className="text-[#f2994a]" />
            <span className="text-lg font-black">{(stats.reads / 1000).toFixed(1)}k</span>
            <span className="text-[8px] opacity-40 uppercase tracking-widest">Reads</span>
          </div>
          <div className="bg-white/5 border border-white/5 p-4 rounded-2xl flex flex-col items-center gap-2">
            <Heart size={16} className="text-[#f2994a]" />
            <span className="text-lg font-black">{(stats.likes / 1000).toFixed(1)}k</span>
            <span className="text-[8px] opacity-40 uppercase tracking-widest">Likes</span>
          </div>
          <div className="bg-white/5 border border-white/5 p-4 rounded-2xl flex flex-col items-center gap-2">
            <DollarSign size={16} className="text-[#f2994a]" />
            <span className="text-lg font-black">{stats.earnings}</span>
            <span className="text-[8px] opacity-40 uppercase tracking-widest">ETB</span>
          </div>
        </section>

        <section className="bg-gradient-to-br from-[#1a1510] to-[#2a1d15] rounded-3xl p-6 border border-[#f2994a]/20 space-y-4">
           <div className="flex justify-between items-center">
             <div className="flex items-center gap-2">
               <BarChart3 size={18} className="text-[#f2994a]" />
               <h2 className="text-[10px] font-black uppercase tracking-widest text-[#f2994a]">Monetization Path</h2>
             </div>
             <span className="text-[10px] font-bold opacity-60">{approvedCount}/3 Approved Stories</span>
           </div>
           
           <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
             <motion.div 
               initial={{ width: 0 }}
               animate={{ width: `${monetizationProgress}%` }}
               className="h-full bg-[#f2994a] shadow-[0_0_10px_#f2994a]"
             />
           </div>

           {monetizationProgress >= 100 ? (
             <button className="w-full py-3 bg-[#f2994a] text-black font-black text-[10px] uppercase tracking-widest rounded-xl">
               Apply for Partner Program
             </button>
           ) : (
             <p className="text-[10px] opacity-40 font-serif italic text-center">
               Add {3 - approvedCount} more approved stories to start earning ETB per read.
             </p>
           )}
        </section>

        <section className="space-y-6">
          <div className="flex bg-white/5 p-1 rounded-xl">
             {(['published', 'pending', 'draft'] as const).map((tab) => (
               <button
                 key={tab}
                 onClick={() => setActiveTab(tab)}
                 className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all ${
                   activeTab === tab ? 'bg-[#2a1d15] text-[#f2994a] shadow-sm' : 'text-white/20'
                 }`}
               >
                 {tab}
               </button>
             ))}
          </div>

          <div className="space-y-4">
            {filteredStories.map((story) => (
              <Link
                key={story.id}
                href={`/story/edit/${story.id}`}
                className="block bg-white/5 border border-white/5 rounded-2xl p-4 flex gap-4 items-center group active:scale-[0.98] transition-all"
              >
                <div className="w-12 h-16 bg-gray-800 rounded-lg relative overflow-hidden flex-shrink-0">
                  {story.cover_url && (
                    <Image 
                      src={story.cover_url} 
                      alt={story.title} 
                      fill 
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                  )}
                </div>
                <div className="flex-1 space-y-1">
                  <h4 className="text-sm font-bold truncate">{story.title}</h4>
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1 text-[9px] opacity-40 uppercase tracking-widest">
                      <Clock size={10} /> {(story.views_count / 100).toFixed(1)}h watch
                    </span>
                    <span className="flex items-center gap-1 text-[9px] font-bold text-[#f2994a] uppercase tracking-widest">
                       {story.status}
                    </span>
                  </div>
                </div>
                <ChevronRight size={20} className="text-white/10 group-hover:text-[#f2994a]" />
              </Link>
            ))}

            {filteredStories.length === 0 && (
              <div className="text-center py-10 opacity-20 italic font-serif text-sm">
                ምንም ታሪክ አልተገኘም (No {activeTab} stories yet)
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
