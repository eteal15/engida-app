'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { 
  ChevronLeft, 
  Check, 
  X, 
  Lock, 
  Unlock, 
  Save, 
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { motion } from 'motion/react';
import Image from 'next/image';

type Story = {
  id: string;
  title: string;
  description: string;
  genre: string;
  status: string;
  cover_url: string;
  profiles: { full_name: string };
};

type Chapter = {
  id: string;
  title: string;
  chapter_number: number;
  is_locked: boolean;
  coin_price: number;
};

export default function StoryReview() {
  const { id } = useParams();
  const router = useRouter();
  const { isAdmin, isLoading: authLoading } = useAuth();
  
  const [story, setStory] = useState<Story | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (!authLoading && !isAdmin) router.push('/home');
  }, [authLoading, isAdmin, router]);

  const fetchData = async () => {
    const [storyRes, chaptersRes] = await Promise.all([
      (supabase.from('stories').select('*, profiles(full_name)').eq('id', id).single() as any),
      (supabase.from('chapters').select('*').eq('story_id', id).order('chapter_number', { ascending: true }) as any)
    ]);

    if (storyRes.data) setStory(storyRes.data as Story);
    if (chaptersRes.data) setChapters(chaptersRes.data as Chapter[]);
    setIsLoading(false);
  };

  useEffect(() => {
    if (isAdmin && id) fetchData();
  }, [isAdmin, id]);

  const handleStoryStatus = async (status: 'approved' | 'rejected') => {
    setIsProcessing(true);
    const { error } = await (supabase.from('stories') as any).update({ status } as any).eq('id', id);
    if (!error) {
      alert(`Story ${status}!`);
      router.push('/stories');
    }
    setIsProcessing(false);
  };

  const updateChapter = async (chapterId: string, updates: Partial<Chapter>) => {
    setChapters(prev => prev.map(c => c.id === chapterId ? { ...c, ...updates } : c));
    const { error } = await (supabase.from('chapters') as any).update(updates as any).eq('id', chapterId);
    if (error) alert('Failed to update chapter');
  };

  if (authLoading || isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;
  if (!story) return null;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf] pb-20">
      <header className="p-6 glass-nav border-b border-white/5 flex items-center gap-4 sticky top-0 z-20">
        <button onClick={() => router.push('/stories')} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center">
          <ChevronLeft size={20} />
        </button>
        <span className="text-[10px] opacity-40 uppercase tracking-widest font-black">Story Review</span>
      </header>

      <main className="p-6 space-y-10 max-w-2xl mx-auto">
        
        {/* Story Summary */}
        <section className="flex gap-6 items-start">
           <div className="w-32 h-44 bg-gray-800 rounded-3xl overflow-hidden relative flex-shrink-0 shadow-2xl">
              {story.cover_url && (
                <Image 
                  src={story.cover_url} 
                  alt={story.title} 
                  fill 
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              )}
           </div>
           <div className="space-y-4">
              <div>
                <h1 className="text-2xl font-serif font-bold text-white">{story.title}</h1>
                <p className="text-[10px] font-black uppercase tracking-widest text-[#f2994a]">{story.genre}</p>
              </div>
              <p className="text-xs opacity-60 leading-relaxed font-serif italic line-clamp-3">
                 {story.description}
              </p>
              <p className="text-[10px] opacity-40 uppercase font-black">Author: {story.profiles?.full_name}</p>
           </div>
        </section>

        {/* Global Review Actions */}
        {story.status === 'pending' && (
          <section className="grid grid-cols-2 gap-4">
             <button 
               disabled={isProcessing}
               onClick={() => handleStoryStatus('approved')}
               className="py-4 bg-green-500 text-black font-black text-[10px] uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2"
             >
                <Check size={16} /> Approve Story
             </button>
             <button 
               disabled={isProcessing}
               onClick={() => handleStoryStatus('rejected')}
               className="py-4 border border-red-500/20 text-red-500 font-black text-[10px] uppercase tracking-widest rounded-2xl flex items-center justify-center gap-2"
             >
                <X size={16} /> Reject
             </button>
          </section>
        )}

        {/* Chapter Management */}
        <section className="space-y-6">
           <div className="flex items-center justify-between">
              <h2 className="text-xs font-black uppercase tracking-widest text-[#f2994a]">Chapters Curation</h2>
              <span className="text-[10px] opacity-30 font-bold">{chapters.length} Chapters Found</span>
           </div>

           <div className="space-y-3">
              {chapters.map((chap) => (
                <div 
                  key={chap.id}
                  className="bg-white/5 border border-white/5 rounded-2xl p-4 flex items-center justify-between gap-4"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-[9px] font-black uppercase text-white/20">CH {chap.chapter_number}</p>
                    <h4 className="text-sm font-bold truncate">{chap.title}</h4>
                  </div>
                  
                  <div className="flex items-center gap-3">
                     {/* Lock Toggle */}
                     <button 
                       onClick={() => updateChapter(chap.id, { is_locked: !chap.is_locked })}
                       className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                         chap.is_locked ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-green-500/10 text-green-500 border border-green-500/20'
                       }`}
                     >
                       {chap.is_locked ? <Lock size={16} /> : <Unlock size={16} />}
                     </button>

                     {/* Price Input */}
                     <div className="relative">
                        <input 
                          type="number"
                          value={chap.coin_price}
                          onChange={(e) => updateChapter(chap.id, { coin_price: parseInt(e.target.value) || 0 })}
                          className="w-16 bg-black/40 border border-white/10 rounded-xl py-2 px-3 text-center text-xs font-black text-[#f2994a] outline-none"
                        />
                     </div>
                  </div>
                </div>
              ))}
           </div>
        </section>

        {/* Warning Note */}
        <div className="bg-[#2a1d15]/30 border border-[#f2994a]/10 rounded-3xl p-6 flex gap-4">
           <AlertTriangle size={20} className="text-[#f2994a] flex-shrink-0" />
           <p className="text-[10px] opacity-60 leading-relaxed font-serif italic">
             "እንደ አድሚን የምዕራፍ መቆለፍ እና ዋጋ መወሰን ሙሉ ስልጣን አለዎት። ይህን ሲያደርጉ የጸሐፊውን ገቢ እና የአንባቢውን እርካታ ያመዛዝኑ።"
             <br /><br />
             As admin, you have full control over chapter monetization. Balance writer earnings with reader accessibility.
           </p>
        </div>
      </main>
    </div>
  );
}
