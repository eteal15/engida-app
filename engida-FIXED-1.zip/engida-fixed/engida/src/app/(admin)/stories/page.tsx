'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/context/AuthProvider';
import { supabase } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';
import { 
  ChevronLeft, 
  Check, 
  X, 
  BookText, 
  Clock,
  ExternalLink,
  ChevronRight,
  Filter
} from 'lucide-react';
import { motion } from 'motion/react';
import Link from 'next/link';
import Image from 'next/image';

type Story = {
  id: string;
  title: string;
  genre: string;
  author_id: string;
  status: string;
  cover_url: string;
  created_at: string;
  profiles: { full_name: string };
};

export default function AdminStories() {
  const { isAdmin, isLoading: authLoading } = useAuth();
  const router = useRouter();
  
  const [stories, setStories] = useState<Story[]>([]);
  const [activeTab, setActiveTab] = useState<'pending' | 'approved'>('pending');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !isAdmin) router.push('/home');
  }, [authLoading, isAdmin, router]);

  const fetchStories = async () => {
    const { data, error } = await (supabase
      .from('stories')
      .select('*, profiles(full_name)')
      .eq('status', activeTab)
      .order('created_at', { ascending: false }) as any);
    
    if (data) setStories(data as Story[]);
    setIsLoading(false);
  };

  useEffect(() => {
    if (isAdmin) {
      setIsLoading(true);
      fetchStories();
    }
  }, [isAdmin, activeTab]);

  if (authLoading || isLoading) return <div className="min-h-screen bg-[#0d0b0a] flex items-center justify-center text-[#f2994a]">በመጫን ላይ...</div>;

  return (
    <div className="min-h-screen bg-[#0d0b0a] text-[#e0d8cf]" id="admin_stories_page">
      <header className="p-6 glass-nav border-b border-white/5 flex items-center gap-4 sticky top-0 z-20">
        <button onClick={() => router.push('/admin-dashboard')} className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center">
          <ChevronLeft size={20} />
        </button>
        <div>
          <h1 className="text-xl font-bold font-serif text-[#f2994a]">Story Curation</h1>
          <p className="text-[10px] opacity-40 uppercase tracking-widest font-black">የታሪኮች ቁጥጥር</p>
        </div>
      </header>

      <main className="p-6 space-y-6">
        <div className="flex bg-white/5 p-1 rounded-xl">
           {(['pending', 'approved'] as const).map((tab) => (
             <button
               key={tab}
               onClick={() => setActiveTab(tab)}
               className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all ${
                 activeTab === tab ? 'bg-[#2a1d15] text-[#f2994a] shadow-sm' : 'text-white/20'
               }`}
             >
               {tab}
             </button>
           ))}
        </div>

        <div className="grid gap-4">
          {stories.map((story) => (
            <Link 
              key={story.id} 
              href={`/stories/${story.id}`}
              className="bg-white/5 border border-white/5 rounded-3xl p-4 flex gap-4 items-center group hover:border-[#f2994a]/30 transition-all"
            >
              <div className="w-16 h-20 bg-gray-800 rounded-xl overflow-hidden relative flex-shrink-0">
                {story.cover_url && (
                  <Image 
                    src={story.cover_url} 
                    alt={story.title} 
                    fill 
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                )}
              </div>
              <div className="flex-1 space-y-1">
                 <h4 className="text-sm font-bold truncate">{story.title}</h4>
                 <div className="flex items-center gap-3">
                    <span className="text-[9px] font-bold text-[#f2994a] uppercase tracking-widest">{story.genre}</span>
                    <span className="text-[9px] opacity-30 uppercase tracking-widest px-2 py-0.5 bg-white/5 rounded-full">
                       by {story.profiles?.full_name}
                    </span>
                 </div>
                 <div className="flex items-center gap-1 text-[8px] opacity-20 uppercase font-black">
                    <Clock size={8} /> {new Date(story.created_at).toLocaleDateString()}
                 </div>
              </div>
              <ChevronRight size={20} className="text-white/10 group-hover:text-[#f2994a]" />
            </Link>
          ))}

          {stories.length === 0 && (
            <div className="text-center py-20 opacity-20 italic font-serif text-sm">
               ምንም ታሪክ የለም (No {activeTab} stories)
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
