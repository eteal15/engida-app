import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { TelegramProvider } from '@/context/TelegramProvider';
import { AuthProvider } from '@/context/AuthProvider';
import Script from 'next/script';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'ENGIDA - Ethiopian Storytelling',
  description: 'Immersive Amharic serialized fiction platform.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <Script
          src="https://telegram.org/js/telegram-web-app.js"
          strategy="beforeInteractive"
        />
      </head>
      <body className={inter.className}>
        <TelegramProvider>
          <AuthProvider>
            {children}
          </AuthProvider>
        </TelegramProvider>
      </body>
    </html>
  );
}
