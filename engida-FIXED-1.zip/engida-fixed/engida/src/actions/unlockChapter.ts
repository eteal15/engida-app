'use client';

import { supabase } from '@/lib/supabaseClient';

/**
 * Atomic Chapter Purchase via Supabase RPC
 * @param chapterId UUID of the chapter to unlock
 */
export async function unlockChapter(chapterId: string) {
  const { data, error } = await (supabase.rpc as any)('unlock_chapter', {
    target_chapter_id: chapterId
  });

  if (error) {
    // Standard error mapping
    if (error.message.includes('Insufficient balance')) {
      throw new Error('ሂሳብዎ ዝቅተኛ ነው (Insufficient balance). Please recharge your wallet.');
    }
    throw error;
  }

  return data;
}
