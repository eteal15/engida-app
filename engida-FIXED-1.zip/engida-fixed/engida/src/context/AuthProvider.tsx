'use client';

import { createContext, useContext, useEffect, useState } from 'react';
import { type User as TelegramUser } from '@telegram-apps/sdk-react';
import { supabase } from '@/lib/supabaseClient';
import { Database } from '@/types/database.types';

type Profile = Database['public']['Tables']['profiles']['Row'];

interface AuthContextType {
  user: TelegramUser | null;
  profile: Profile | null;
  balance: number;
  isLoading: boolean;
  isAdmin: boolean;
  isWriter: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // We use a try-catch pattern or check environment to avoid crashing if SDKProvider was skipped
  const [lp, setLp] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [balance, setBalance] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  // Safely get launch params if available
  useEffect(() => {
    try {
      // Direct access attempt if not using hook to avoid context error
      const isTelegram = typeof window !== 'undefined' && (window as any).Telegram?.WebApp?.initData;
      if (isTelegram) {
        // Only attempt to use SDK if in Telegram
        import('@telegram-apps/sdk-react').then(({ retrieveLaunchParams }) => {
          try {
            const params = retrieveLaunchParams();
            setLp(params);
          } catch (e) {
            console.error('Failed to retrieve LP', e);
          }
        });
      } else {
        console.log('Not in Telegram, skipping LP retrieval');
        setIsLoading(false);
      }
    } catch (err) {
      console.error('Environment check error', err);
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    async function syncUser() {
      if (!lp?.initData?.user) {
        // In local development without Telegram, we might want to mock a user
        // for testing flows, but for now we'll just stop loading.
        if (!isLoading) return; // Already handled
        return;
      }

      const tgUser = lp.initData.user;
      
      try {
        // 1. Check if profile exists
        const { data: existingProfile, error: fetchError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', tgUser.id.toString())
          .single();

        if (existingProfile) {
          setProfile(existingProfile as Profile);
          // Fetch balance
          const { data: wallet } = await supabase
            .from('coin_wallets')
            .select('balance')
            .eq('user_id', tgUser.id.toString())
            .single();
          if (wallet) setBalance((wallet as { balance: number }).balance);
        } else {
          // 2. Provision User (Triggers in DB handle wallet creation)
          // @ts-ignore
          const { data: newProfile } = await (supabase.from('profiles') as any)
            .insert({
              id: tgUser.id.toString(),
              full_name: `${tgUser.firstName} ${tgUser.lastName || ''}`.trim(),
              username: tgUser.username,
              avatar_url: tgUser.photoUrl,
              role: 'Reader'
            })
            .select()
            .single();

          if (newProfile) setProfile(newProfile as Profile);
        }
      } catch (err) {
        console.error('Auth sync error:', err);
      } finally {
        setIsLoading(false);
      }
    }

    syncUser();
  }, [lp]);

  const value = {
    user: lp?.initData?.user || null,
    profile,
    balance,
    isLoading,
    isAdmin: profile?.role === 'Admin',
    isWriter: profile?.role === 'Writer',
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
