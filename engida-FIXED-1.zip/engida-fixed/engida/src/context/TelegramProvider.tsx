'use client';

import { SDKProvider } from '@telegram-apps/sdk-react';
import { type PropsWithChildren, useEffect, useState } from 'react';

export function TelegramProvider({ children }: PropsWithChildren) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) return <>{children}</>;

  // Check if we are actually in Telegram
  const isTelegram = typeof window !== 'undefined' && (window as any).Telegram?.WebApp?.initData;

  if (!isTelegram && process.env.NODE_ENV === 'development') {
    // In dev/preview outside Telegram, we skip SDKProvider to avoid setup errors
    // but we need to be careful as hooks like useLaunchParams will fail if called.
    return <>{children}</>;
  }

  return (
    <SDKProvider acceptCustomStyles>
      {children}
    </SDKProvider>
  );
}
