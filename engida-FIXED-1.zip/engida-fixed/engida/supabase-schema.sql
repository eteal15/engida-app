-- ENGIDA (እንግዳ) - Database Schema Migration
-- Target: Supabase (PostgreSQL)

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS & TYPES
CREATE TYPE user_role AS ENUM ('Reader', 'Writer', 'Admin');
CREATE TYPE story_status AS ENUM ('draft', 'pending', 'approved', 'rejected');
CREATE TYPE interaction_type AS ENUM ('like', 'bookmark', 'reading_history');
CREATE TYPE transaction_type AS ENUM ('deposit', 'purchase', 'payout');

-- 3. TABLES

-- Profiles (Linked to Supabase Auth)
CREATE TABLE public.profiles (
    id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
    username TEXT UNIQUE,
    full_name TEXT,
    avatar_url TEXT,
    bio TEXT,
    role user_role DEFAULT 'Reader' NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Stories
CREATE TABLE public.stories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    author_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    cover_url TEXT,
    genre TEXT,
    status story_status DEFAULT 'draft' NOT NULL,
    views_count BIGINT DEFAULT 0,
    likes_count BIGINT DEFAULT 0,
    search_vector TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', title || ' ' || COALESCE(description, ''))) STORED,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Chapters
CREATE TABLE public.chapters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    story_id UUID REFERENCES public.stories(id) ON DELETE CASCADE NOT NULL,
    chapter_number INT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL, -- Rich text/Markdown
    is_locked BOOLEAN DEFAULT FALSE,
    coin_price INT DEFAULT 5, -- Default price (e.g., 5 coins ~ 20 ETB equivalent)
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(story_id, chapter_number)
);

-- Coin Wallets
CREATE TABLE public.coin_wallets (
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE PRIMARY KEY,
    balance INT DEFAULT 0 CHECK (balance >= 0) NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Transactions (Telebirr Records / Chapter Purchases)
CREATE TABLE public.transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.profiles(id) NOT NULL,
    type transaction_type NOT NULL,
    amount INT NOT NULL, -- Negative for purchases, positive for deposits
    reference_id TEXT UNIQUE, -- Telebirr Transaction ID or unique hash
    screenshot_url TEXT, -- For manual verification of Telebirr deposits
    status TEXT DEFAULT 'pending' NOT NULL, -- 'pending', 'completed', 'failed'
    metadata JSONB, -- Storing extra info like chapter_id
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Chapter Unlocks (Ledger)
CREATE TABLE public.chapter_unlocks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    chapter_id UUID REFERENCES public.chapters(id) ON DELETE CASCADE NOT NULL,
    unlocked_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, chapter_id)
);

-- User Interactions
CREATE TABLE public.user_interactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    story_id UUID REFERENCES public.stories(id) ON DELETE CASCADE NOT NULL,
    chapter_id UUID REFERENCES public.chapters(id) ON DELETE CASCADE, -- Optional for reading history
    type interaction_type NOT NULL,
    last_position INT DEFAULT 0, -- For 'resume from last chapter' history
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, story_id, type)
);

-- Monetization Requests & Payouts
CREATE TABLE public.monetization_requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    writer_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    status TEXT DEFAULT 'pending' NOT NULL, -- 'pending', 'approved', 'rejected'
    total_stories_completed INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE public.payout_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    writer_id UUID REFERENCES public.profiles(id) NOT NULL,
    amount_etb DECIMAL(10,2) NOT NULL,
    status TEXT DEFAULT 'processing' NOT NULL,
    transfer_reference TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. PERFORMANCE INDEXES
CREATE INDEX idx_stories_status ON public.stories(status);
CREATE INDEX idx_stories_genre ON public.stories(genre);
CREATE INDEX idx_chapters_story_id ON public.chapters(story_id);
CREATE INDEX idx_stories_search ON public.stories USING gin(search_vector);
CREATE INDEX idx_interactions_user_history ON public.user_interactions(user_id, type);

-- 5. ROW-LEVEL SECURITY (RLS) policies

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coin_wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapter_unlocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_interactions ENABLE ROW LEVEL SECURITY;

-- Profiles: Anyone can see profiles (for author names), but only owners can edit
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles
    FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

-- Stories: Anyone can see 'approved' stories. Writers see their own.
CREATE POLICY "Approved stories are public" ON public.stories
    FOR SELECT USING (status = 'approved');
CREATE POLICY "Authors can manage their stories" ON public.stories
    FOR ALL USING (auth.uid() = author_id);
CREATE POLICY "Admins can manage all stories" ON public.stories
    FOR ALL TO authenticated USING (
        EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'Admin')
    );

-- Chapters: Free chapters are public. Locked chapters require 'chapter_unlocks' record.
CREATE POLICY "Free chapters are public" ON public.chapters
    FOR SELECT USING (
        is_locked = false AND 
        EXISTS (SELECT 1 FROM public.stories WHERE id = chapters.story_id AND status = 'approved')
    );
CREATE POLICY "Unlocked chapters are viewable" ON public.chapters
    FOR SELECT USING (
        EXISTS (SELECT 1 FROM public.chapter_unlocks WHERE user_id = auth.uid() AND chapter_id = chapters.id)
    );
CREATE POLICY "Authors can manage their chapters" ON public.chapters
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.stories WHERE id = chapters.story_id AND author_id = auth.uid())
    );

-- Wallets & Unlocks: Owner only
CREATE POLICY "Users can see own wallet" ON public.coin_wallets
    FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can see own unlocks" ON public.chapter_unlocks
    FOR SELECT USING (auth.uid() = user_id);

-- 6. TRIGGERS & FUNCTIONS

-- Automatically create profile and wallet on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, full_name, avatar_url, role)
    VALUES (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'avatar_url', 'Reader');
    
    INSERT INTO public.coin_wallets (user_id, balance)
    VALUES (new.id, 0);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Atomic Chapter Purchase Function
CREATE OR REPLACE FUNCTION public.unlock_chapter(target_chapter_id UUID)
RETURNS VOID AS $$
DECLARE
    chapter_price INT;
    user_balance INT;
BEGIN
    -- 1. Get chapter price
    SELECT coin_price INTO chapter_price FROM public.chapters WHERE id = target_chapter_id;
    
    -- 2. Validate price and user balance
    SELECT balance INTO user_balance FROM public.coin_wallets WHERE user_id = auth.uid();
    
    IF user_balance < chapter_price THEN
        RAISE EXCEPTION 'Insufficient balance';
    END IF;

    -- 3. Deduct balance
    UPDATE public.coin_wallets
    SET balance = balance - chapter_price
    WHERE user_id = auth.uid();

    -- 4. Record interaction (Transaction)
    INSERT INTO public.transactions (user_id, type, amount, metadata)
    VALUES (auth.uid(), 'purchase', -chapter_price, jsonb_build_object('chapter_id', target_chapter_id));

    -- 5. Add to unlocks ledger
    INSERT INTO public.chapter_unlocks (user_id, chapter_id)
    VALUES (auth.uid(), target_chapter_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
